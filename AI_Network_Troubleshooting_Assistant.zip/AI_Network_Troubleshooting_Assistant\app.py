"""
app.py - Flask backend for AI Network Troubleshooting Assistant.

Run with: py -3 app.py
Then open http://localhost:5000 in your browser.
"""

import json
import os
from datetime import datetime
from flask import Flask, render_template, jsonify, request, make_response

from diagnostics.network_info import get_network_info, get_connection_summary
from diagnostics.ping_test import run_ping, validate_target
from diagnostics.dns_lookup import run_dns_lookup, get_dns_servers
from diagnostics.traceroute import run_traceroute
from diagnostics.port_checker import check_port, get_common_ports, check_multiple_ports
from diagnostics.troubleshooter import TroubleshootingEngine

app = Flask(__name__)
engine = TroubleshootingEngine()


# ─── Helper ──────────────────────────────────────────────────────────────────

def _error(message: str, code: int = 400):
    return jsonify({"error": message, "success": False}), code


# ─── Page Routes ─────────────────────────────────────────────────────────────

@app.route("/")
def index():
    return render_template("index.html")


# ─── API: Network Information ─────────────────────────────────────────────────

@app.route("/api/network-info", methods=["GET"])
def api_network_info():
    try:
        info = get_network_info()
        info["connection_summary"] = get_connection_summary(info)
        return jsonify(info)
    except Exception as e:
        return _error(f"Failed to get network info: {str(e)}", 500)


# ─── API: Ping ────────────────────────────────────────────────────────────────

@app.route("/api/ping", methods=["POST"])
def api_ping():
    try:
        data = request.get_json(silent=True) or {}
        target = str(data.get("target", "")).strip()
        count = data.get("count", 4)

        # Validate
        is_valid, err = validate_target(target)
        if not is_valid:
            return _error(err, 400)

        try:
            count = int(count)
            count = max(1, min(count, 10))
        except (TypeError, ValueError):
            count = 4

        result = run_ping(target, count)
        return jsonify(result)
    except Exception as e:
        return _error(f"Ping error: {str(e)}", 500)


# ─── API: DNS Lookup ──────────────────────────────────────────────────────────

@app.route("/api/dns-lookup", methods=["POST"])
def api_dns_lookup():
    try:
        data = request.get_json(silent=True) or {}
        domain = str(data.get("domain", "")).strip()

        if not domain:
            return _error("Domain name cannot be empty.", 400)
        if len(domain) > 253:
            return _error("Domain name is too long.", 400)

        result = run_dns_lookup(domain)
        result["dns_servers"] = get_dns_servers()
        return jsonify(result)
    except Exception as e:
        return _error(f"DNS lookup error: {str(e)}", 500)


# ─── API: Traceroute ──────────────────────────────────────────────────────────

@app.route("/api/traceroute", methods=["POST"])
def api_traceroute():
    try:
        data = request.get_json(silent=True) or {}
        target = str(data.get("target", "")).strip()
        max_hops = data.get("max_hops", 30)

        is_valid, err = validate_target(target)
        if not is_valid:
            return _error(err, 400)

        try:
            max_hops = int(max_hops)
            max_hops = max(1, min(max_hops, 30))
        except (TypeError, ValueError):
            max_hops = 30

        result = run_traceroute(target, max_hops)
        return jsonify(result)
    except Exception as e:
        return _error(f"Traceroute error: {str(e)}", 500)


# ─── API: Port Check ──────────────────────────────────────────────────────────

@app.route("/api/port-check", methods=["POST"])
def api_port_check():
    try:
        data = request.get_json(silent=True) or {}
        host = str(data.get("host", "")).strip()
        port = data.get("port", 80)
        timeout = data.get("timeout", 5.0)

        if not host:
            return _error("Host cannot be empty.", 400)

        try:
            port = int(port)
        except (TypeError, ValueError):
            return _error("Port must be a number.", 400)

        if port < 1 or port > 65535:
            return _error("Port must be between 1 and 65535.", 400)

        try:
            timeout = float(timeout)
            timeout = max(0.5, min(timeout, 30.0))
        except (TypeError, ValueError):
            timeout = 5.0

        result = check_port(host, port, timeout)
        return jsonify(result)
    except Exception as e:
        return _error(f"Port check error: {str(e)}", 500)


# ─── API: Common Ports ────────────────────────────────────────────────────────

@app.route("/api/common-ports", methods=["GET"])
def api_common_ports():
    try:
        return jsonify(get_common_ports())
    except Exception as e:
        return _error(f"Error: {str(e)}", 500)


# ─── API: Analyse ─────────────────────────────────────────────────────────────

@app.route("/api/analyse", methods=["POST"])
def api_analyse():
    try:
        data = request.get_json(silent=True) or {}
        result = engine.analyse(data)
        return jsonify(result)
    except Exception as e:
        return _error(f"Analysis error: {str(e)}", 500)


# ─── API: Quick Diagnose ──────────────────────────────────────────────────────

@app.route("/api/quick-diagnose", methods=["POST"])
def api_quick_diagnose():
    """
    Run an automatic multi-step diagnosis:
    1. Get network info
    2. Ping the default gateway (if available)
    3. Ping 8.8.8.8 (Google DNS)
    4. DNS lookup for google.com
    5. Run the troubleshooting analysis on collected results
    """
    try:
        results = {}

        # Step 1: Network info
        net_info = get_network_info()
        results["network_info"] = net_info

        # Step 2: Ping gateway
        gateway = net_info.get("gateway", "")
        if gateway and gateway not in ("Unavailable", ""):
            results["ping_gateway_result"] = run_ping(gateway, count=2)

        # Step 3: Ping internet (Google DNS)
        results["ping_internet_result"] = run_ping("8.8.8.8", count=2)

        # Step 4: DNS lookup
        results["dns_result"] = run_dns_lookup("google.com")

        # Step 5: Analyse
        analysis = engine.analyse(results)
        results["analysis"] = analysis

        return jsonify(results)
    except Exception as e:
        return _error(f"Quick diagnose error: {str(e)}", 500)


# ─── API: Download Report ─────────────────────────────────────────────────────

@app.route("/api/download-report", methods=["POST"])
def api_download_report():
    """
    Generate and return a downloadable diagnostic report.
    POST body: { "format": "txt"|"json", "data": { ... } }
    """
    try:
        body = request.get_json(silent=True) or {}
        fmt = str(body.get("format", "txt")).lower()
        data = body.get("data", {})

        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        filename_ts = datetime.now().strftime("%Y%m%d_%H%M%S")

        if fmt == "json":
            content = json.dumps(data, indent=2, default=str)
            response = make_response(content)
            response.headers["Content-Disposition"] = (
                f'attachment; filename="network_report_{filename_ts}.json"'
            )
            response.headers["Content-Type"] = "application/json"
            return response
        else:
            # Plain text report
            lines = []
            sep = "=" * 60

            lines.append(sep)
            lines.append("  AI NETWORK TROUBLESHOOTING ASSISTANT")
            lines.append("  Diagnostic Report")
            lines.append(f"  Generated: {timestamp}")
            lines.append(sep)
            lines.append("")

            # Network Info
            net = data.get("network_info", {})
            if net:
                lines.append("── NETWORK INFORMATION ──────────────────────────────────")
                lines.append(f"  Hostname       : {net.get('hostname', 'N/A')}")
                lines.append(f"  Local IP       : {net.get('local_ip', 'N/A')}")
                lines.append(f"  Subnet Mask    : {net.get('subnet_mask', 'N/A')}")
                lines.append(f"  Default Gateway: {net.get('gateway', 'N/A')}")
                lines.append(f"  Interface      : {net.get('interface_name', 'N/A')}")
                lines.append(f"  DNS Servers    : {', '.join(net.get('dns_servers', [])) or 'N/A'}")
                lines.append(f"  Connection     : {net.get('connection_type', 'N/A')}")
                lines.append("")

            # Ping results
            for key in ("ping_gateway_result", "ping_internet_result", "ping_result"):
                ping = data.get(key, {})
                if ping:
                    label = {
                        "ping_gateway_result": "PING — GATEWAY",
                        "ping_internet_result": "PING — INTERNET (8.8.8.8)",
                        "ping_result": "PING TEST",
                    }[key]
                    lines.append(f"── {label} {'─' * (55 - len(label))}")
                    lines.append(f"  Target         : {ping.get('target', 'N/A')}")
                    lines.append(f"  Status         : {'SUCCESS' if ping.get('success') else 'FAILED'}")
                    lines.append(f"  Avg Latency    : {ping.get('avg_latency_ms', 'N/A')} ms")
                    lines.append(f"  Packet Loss    : {ping.get('packet_loss_pct', 'N/A')}%")
                    if ping.get("error"):
                        lines.append(f"  Error          : {ping.get('error')}")
                    lines.append("")

            # DNS
            dns = data.get("dns_result", {})
            if dns:
                lines.append("── DNS LOOKUP ───────────────────────────────────────────")
                lines.append(f"  Domain         : {dns.get('domain', 'N/A')}")
                lines.append(f"  Status         : {'SUCCESS' if dns.get('success') else 'FAILED'}")
                lines.append(f"  Resolved IPs   : {', '.join(dns.get('resolved_ips', [])) or 'N/A'}")
                lines.append(f"  Resolution Time: {dns.get('resolution_time_ms', 'N/A')} ms")
                if dns.get("error"):
                    lines.append(f"  Error          : {dns.get('error')}")
                lines.append("")

            # Traceroute
            tr = data.get("traceroute_result", {})
            if tr:
                lines.append("── TRACEROUTE ───────────────────────────────────────────")
                lines.append(f"  Target         : {tr.get('target', 'N/A')}")
                lines.append(f"  Status         : {'SUCCESS' if tr.get('success') else 'FAILED'}")
                lines.append(f"  Total Hops     : {tr.get('total_hops', 'N/A')}")
                lines.append(f"  Reached Dest.  : {'Yes' if tr.get('reached_destination') else 'No'}")
                hops = tr.get("hops", [])
                for hop in hops[:20]:  # Limit to 20 hops in report
                    lat_str = " / ".join(
                        f"{l:.0f}ms" if l is not None else "*" for l in hop.get("latencies", [])
                    )
                    lines.append(f"  Hop {hop.get('hop_num', '?'):2d}        : {hop.get('ip', '?')} ({lat_str})")
                lines.append("")

            # Port check
            port = data.get("port_result", {})
            if port:
                lines.append("── PORT CONNECTIVITY ────────────────────────────────────")
                lines.append(f"  Host           : {port.get('host', 'N/A')}")
                lines.append(f"  Port           : {port.get('port', 'N/A')} ({port.get('service_name', 'N/A')})")
                lines.append(f"  Status         : {'OPEN' if port.get('success') else 'CLOSED/FILTERED'}")
                lines.append(f"  Connection Time: {port.get('connection_time_ms', 'N/A')} ms")
                if port.get("error"):
                    lines.append(f"  Error          : {port.get('error')}")
                lines.append("")

            # Analysis
            analysis = data.get("analysis", {})
            if analysis:
                lines.append("── AI TROUBLESHOOTING ANALYSIS ──────────────────────────")
                lines.append(f"  Overall Health : {analysis.get('overall_health', 'N/A')}")
                lines.append(f"  Health Score   : {analysis.get('health_score', 'N/A')}/100")
                lines.append(f"  Summary        : {analysis.get('summary', 'N/A')}")
                lines.append("")
                for issue in analysis.get("issues", []):
                    lines.append(f"  [{issue.get('severity', '?').upper()}] {issue.get('title', '')}")
                    lines.append(f"    Evidence  : {issue.get('evidence', '')}")
                    lines.append(f"    Cause     : {issue.get('possible_cause', '')}")
                    lines.append(f"    Solution  :")
                    for step in issue.get("recommended_solution", []):
                        lines.append(f"      {step}")
                    lines.append("")

            lines.append(sep)
            lines.append("  End of Report")
            lines.append(sep)

            content = "\n".join(lines)
            response = make_response(content)
            response.headers["Content-Disposition"] = (
                f'attachment; filename="network_report_{filename_ts}.txt"'
            )
            response.headers["Content-Type"] = "text/plain; charset=utf-8"
            return response

    except Exception as e:
        return _error(f"Report generation error: {str(e)}", 500)


# ─── Error Handlers ───────────────────────────────────────────────────────────

@app.errorhandler(400)
def bad_request(e):
    return jsonify({"error": "Bad request", "details": str(e)}), 400


@app.errorhandler(404)
def not_found(e):
    return jsonify({"error": "Endpoint not found"}), 404


@app.errorhandler(500)
def server_error(e):
    return jsonify({"error": "Internal server error", "details": str(e)}), 500


# ─── Main ─────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    print("=" * 50)
    print("  AI Network Troubleshooting Assistant")
    print("  Starting Flask server...")
    print("  Open http://localhost:5000 in your browser")
    print("  Press Ctrl+C to stop the server")
    print("=" * 50)
    app.run(debug=False, host="0.0.0.0", port=5000)
