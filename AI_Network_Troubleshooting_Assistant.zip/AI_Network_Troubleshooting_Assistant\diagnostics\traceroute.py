"""
traceroute.py - Trace network routes using tracert (Windows) or traceroute (Linux/macOS).
No external dependencies. No admin privileges required for ICMP traceroute on Windows.
"""

import subprocess
import re
import platform
from datetime import datetime


_DANGEROUS_CHARS = set(';&|`$(){}[]<>\'"\\')


def validate_target(target: str) -> tuple:
    """Validate target hostname or IP. Returns (is_valid, error_message)."""
    if not target:
        return False, "Target cannot be empty."
    target = target.strip()
    if len(target) > 253:
        return False, "Target is too long (max 253 characters)."
    if any(c in _DANGEROUS_CHARS for c in target):
        return False, "Target contains invalid characters."
    if not re.match(r'^[a-zA-Z0-9.\-_]+$', target):
        return False, "Target contains unsupported characters."
    return True, ""


def _parse_latency(text: str):
    """
    Parse a latency value like '12 ms' or '12ms' or '<1 ms'.
    Returns float (ms) or None if it's a timeout ('*').
    """
    text = text.strip()
    if text == "*":
        return None
    # Handle '<1 ms'
    if text.startswith("<"):
        return 0.5
    m = re.search(r"([\d.]+)\s*ms", text, re.IGNORECASE)
    if m:
        return float(m.group(1))
    return None


def _parse_windows_tracert(output: str) -> list:
    """
    Parse tracert output on Windows.

    Windows tracert line format:
      1    <1 ms    <1 ms    <1 ms  192.168.1.1
      2     *        *        *     Request timed out.
    """
    hops = []

    for line in output.splitlines():
        line = line.strip()

        # Match hop lines: starts with a number
        # Format: num  lat1  lat2  lat3  host/ip
        m = re.match(
            r'^(\d+)\s+'
            r'([*\d<\s]+?ms|\*)\s+'
            r'([*\d<\s]+?ms|\*)\s+'
            r'([*\d<\s]+?ms|\*)\s+'
            r'(.+)$',
            line, re.IGNORECASE
        )
        if not m:
            # Try simpler pattern for timeout lines
            m2 = re.match(r'^(\d+)\s+\*\s+\*\s+\*\s*(.*)$', line)
            if m2:
                hop_num = int(m2.group(1))
                hops.append({
                    "hop_num": hop_num,
                    "latencies": [None, None, None],
                    "avg_latency_ms": None,
                    "ip": "* * *",
                    "is_timeout": True,
                })
            continue

        hop_num = int(m.group(1))
        lat1 = _parse_latency(m.group(2))
        lat2 = _parse_latency(m.group(3))
        lat3 = _parse_latency(m.group(4))
        host = m.group(5).strip()

        # Clean up host (remove "Request timed out." etc.)
        if "request timed out" in host.lower():
            host = "* * *"
            lat1 = lat2 = lat3 = None

        latencies = [lat1, lat2, lat3]
        valid_lats = [l for l in latencies if l is not None]
        avg = round(sum(valid_lats) / len(valid_lats), 2) if valid_lats else None

        hops.append({
            "hop_num": hop_num,
            "latencies": latencies,
            "avg_latency_ms": avg,
            "ip": host,
            "is_timeout": all(l is None for l in latencies),
        })

    return hops


def _parse_unix_traceroute(output: str) -> list:
    """Parse traceroute output on Linux/macOS."""
    hops = []

    for line in output.splitlines():
        line = line.strip()
        m = re.match(r'^(\d+)\s+(.*)', line)
        if not m:
            continue

        hop_num = int(m.group(1))
        rest = m.group(2).strip()

        if rest.startswith("*"):
            hops.append({
                "hop_num": hop_num,
                "latencies": [None, None, None],
                "avg_latency_ms": None,
                "ip": "* * *",
                "is_timeout": True,
            })
            continue

        # Extract IP or hostname
        ip_match = re.search(r'([\d.]+|\([^)]+\))', rest)
        ip = ip_match.group(1).strip("()") if ip_match else "Unknown"

        # Extract latencies
        lat_matches = re.findall(r'([\d.]+)\s*ms|\*', rest)
        latencies = []
        for lm in lat_matches[:3]:
            latencies.append(float(lm) if lm else None)
        while len(latencies) < 3:
            latencies.append(None)

        valid_lats = [l for l in latencies if l is not None]
        avg = round(sum(valid_lats) / len(valid_lats), 2) if valid_lats else None

        hops.append({
            "hop_num": hop_num,
            "latencies": latencies,
            "avg_latency_ms": avg,
            "ip": ip,
            "is_timeout": all(l is None for l in latencies),
        })

    return hops


def run_traceroute(target: str, max_hops: int = 30) -> dict:
    """
    Trace the route to a target host.

    Args:
        target: IP or hostname
        max_hops: Maximum number of hops (1-30)

    Returns:
        dict with traceroute results. Never crashes.
    """
    timestamp = datetime.now().isoformat()

    is_valid, error_msg = validate_target(target)
    if not is_valid:
        return {
            "success": False,
            "target": target,
            "hops": [],
            "total_hops": 0,
            "reached_destination": False,
            "error": error_msg,
            "raw_output": "",
            "timestamp": timestamp,
        }

    target = target.strip()
    max_hops = max(1, min(max_hops, 30))

    result = {
        "success": False,
        "target": target,
        "hops": [],
        "total_hops": 0,
        "reached_destination": False,
        "error": None,
        "raw_output": "",
        "timestamp": timestamp,
    }

    is_windows = platform.system() == "Windows"

    if is_windows:
        cmd = ["tracert", "-d", "-h", str(max_hops), target]
    else:
        cmd = ["traceroute", "-n", "-m", str(max_hops), target]

    try:
        proc = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=120,
            encoding="utf-8",
            errors="replace",
        )
        output = proc.stdout + proc.stderr
        result["raw_output"] = output.strip()

        # Parse hops
        if is_windows:
            hops = _parse_windows_tracert(output)
        else:
            hops = _parse_unix_traceroute(output)

        result["hops"] = hops
        result["total_hops"] = len(hops)

        # Check if destination was reached
        if hops:
            last_hop = hops[-1]
            if not last_hop["is_timeout"] and last_hop["ip"] not in ("* * *", "Unknown"):
                result["reached_destination"] = True

        # Success if we got at least one hop
        if hops or proc.returncode == 0:
            result["success"] = True

        # Check for error messages in output
        if "could not find host" in output.lower() or "unable to resolve" in output.lower():
            result["success"] = False
            result["error"] = f"Could not resolve hostname: {target}"
        elif not hops and proc.returncode != 0:
            result["error"] = f"Traceroute failed (exit code {proc.returncode})"

    except subprocess.TimeoutExpired:
        result["error"] = "Traceroute timed out after 2 minutes"
    except FileNotFoundError:
        cmd_name = "tracert" if is_windows else "traceroute"
        result["error"] = (
            f"'{cmd_name}' command not found. "
            "On Windows, this should be available by default."
        )
    except PermissionError:
        result["error"] = "Permission denied running traceroute."
    except Exception as e:
        result["error"] = f"Unexpected error: {str(e)}"

    return result


if __name__ == "__main__":
    import json
    print("Traceroute to 8.8.8.8 ...")
    r = run_traceroute("8.8.8.8", max_hops=10)
    print(json.dumps(r, indent=2))
