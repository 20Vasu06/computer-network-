"""
test_suite.py — Automated Test & Validation Suite for AI Network Troubleshooting Assistant.
Suitable for lab evaluation and project demonstration.

Run with:
    py test_suite.py
"""

import sys
import unittest
import json
from app import app
from diagnostics.network_info import get_network_info, parse_ipconfig
from diagnostics.ping_test import run_ping, validate_target
from diagnostics.dns_lookup import run_dns_lookup, validate_domain
from diagnostics.port_checker import check_port, validate_port, validate_host, get_common_ports
from diagnostics.troubleshooter import TroubleshootingEngine


class TestNetworkDiagnostics(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        print("\n" + "=" * 65)
        print("  AI NETWORK TROUBLESHOOTING ASSISTANT — AUTOMATED TEST SUITE")
        print("=" * 65 + "\n")

    def test_01_input_validation(self):
        """Verify regex and character sanitization prevents shell injections."""
        print("[RUNNING] Test 01: Input Validation & Security Checks")
        
        # Valid targets
        ok, _ = validate_target("google.com")
        self.assertTrue(ok)
        ok, _ = validate_target("127.0.0.1")
        self.assertTrue(ok)
        
        # Injection attacks & illegal characters
        bad_inputs = [
            "",
            "google.com; rm -rf /",
            "127.0.0.1 & dir",
            "test | cat /etc/passwd",
            "`calc.exe`",
            "a" * 255
        ]
        for bad in bad_inputs:
            ok, msg = validate_target(bad)
            self.assertFalse(ok, f"Failed to reject dangerous input: {bad}")
            self.assertTrue(len(msg) > 0)
            
        print("  [PASS] Shell metacharacters and empty/oversized inputs successfully rejected.")

    def test_02_network_info_structure(self):
        """Verify network info discovery returns non-crashing schema."""
        print("[RUNNING] Test 02: Local Network Information Module")
        info = get_network_info()
        self.assertIsInstance(info, dict)
        self.assertIn("hostname", info)
        self.assertIn("local_ip", info)
        self.assertIn("gateway", info)
        self.assertIn("dns_servers", info)
        self.assertIn("connection_type", info)
        print(f"  [PASS] Hostname: {info.get('hostname')}, IP: {info.get('local_ip')}")

    def test_03_ping_functionality(self):
        """Test ICMP ping execution and parsing."""
        print("[RUNNING] Test 03: ICMP Ping Execution (localhost)")
        res = run_ping("127.0.0.1", count=2)
        self.assertIsInstance(res, dict)
        self.assertTrue(res.get("success"))
        self.assertEqual(res.get("packets_sent"), 2)
        self.assertEqual(res.get("packets_received"), 2)
        self.assertEqual(res.get("packet_loss_pct"), 0.0)
        self.assertIsNotNone(res.get("avg_latency_ms"))
        print(f"  [PASS] Localhost ping: 0% loss, Avg RTT = {res.get('avg_latency_ms')} ms")

    def test_04_dns_resolution(self):
        """Test DNS A/AAAA record resolution."""
        print("[RUNNING] Test 04: DNS Name Resolution (google.com)")
        res = run_dns_lookup("google.com")
        self.assertIsInstance(res, dict)
        self.assertTrue(res.get("success"))
        self.assertGreater(len(res.get("resolved_ips", [])), 0)
        self.assertIsNotNone(res.get("resolution_time_ms"))
        print(f"  [PASS] Resolved IPs: {res.get('resolved_ips')[:2]} in {res.get('resolution_time_ms')} ms")

    def test_05_port_checker(self):
        """Test TCP socket connection and refusal/timeout handling."""
        print("[RUNNING] Test 05: Port Connectivity Verification")
        # Validation checks
        ok, _ = validate_port(80)
        self.assertTrue(ok)
        ok, _ = validate_port(99999)
        self.assertFalse(ok)
        
        # Test port 80 check on a reliable host
        res = check_port("google.com", 80, timeout=3.0)
        self.assertIsInstance(res, dict)
        self.assertTrue(res.get("success"))
        self.assertEqual(res.get("service_name"), "HTTP")
        print(f"  [PASS] google.com:80 (HTTP) -> OPEN in {res.get('connection_time_ms')} ms")

    def test_06_troubleshooting_engine_rules(self):
        """Test deterministic rule-based expert troubleshooting engine."""
        print("[RUNNING] Test 06: Rule-Based Troubleshooting Engine Logic")
        engine = TroubleshootingEngine()

        # Scenario A: DNS Failure
        analysis_dns = engine.analyse({
            "dns_result": {
                "success": False,
                "domain": "broken.invalid",
                "error": "getaddrinfo failed: nodename nor servname provided"
            }
        })
        self.assertIn("Fair", ["Fair", "Poor"])
        issue_ids = [i["id"] for i in analysis_dns["issues"]]
        self.assertIn("dns_failure", issue_ids)
        self.assertEqual(analysis_dns["health_score"], 75)

        # Scenario B: Critical Gateway Failure
        analysis_gw = engine.analyse({
            "network_info": {"gateway": "192.168.1.1", "local_ip": "192.168.1.50"},
            "ping_gateway_result": {"success": False, "error": "Request timed out"}
        })
        issue_ids_gw = [i["id"] for i in analysis_gw["issues"]]
        self.assertIn("gateway_unreachable", issue_ids_gw)
        self.assertLessEqual(analysis_gw["health_score"], 60)

        # Scenario C: Healthy State
        analysis_healthy = engine.analyse({
            "ping_internet_result": {"success": True, "avg_latency_ms": 20.0, "packet_loss_pct": 0.0},
            "dns_result": {"success": True, "resolved_ips": ["1.1.1.1"]},
        })
        self.assertEqual(analysis_healthy["overall_health"], "Good")
        self.assertEqual(analysis_healthy["health_score"], 100)
        print("  [PASS] Engine accurately diagnoses DNS failures, Gateway disconnects, and healthy states.")

    def test_07_flask_endpoints(self):
        """Test web server REST endpoints."""
        print("[RUNNING] Test 07: Flask API Endpoints & Report Generation")
        client = app.test_client()

        # GET Index
        res = client.get("/")
        self.assertEqual(res.status_code, 200)

        # GET Network Info
        res = client.get("/api/network-info")
        self.assertEqual(res.status_code, 200)

        # POST Ping bad input -> 400
        res = client.post("/api/ping", json={"target": ""})
        self.assertEqual(res.status_code, 400)

        # POST Quick Diagnose
        res = client.post("/api/quick-diagnose", json={})
        self.assertEqual(res.status_code, 200)
        data = json.loads(res.data)
        self.assertIn("analysis", data)

        # POST Download Report (txt and json)
        res_txt = client.post("/api/download-report", json={"format": "txt", "data": data})
        self.assertEqual(res_txt.status_code, 200)
        self.assertIn(b"AI NETWORK TROUBLESHOOTING ASSISTANT", res_txt.data)

        res_json = client.post("/api/download-report", json={"format": "json", "data": data})
        self.assertEqual(res_json.status_code, 200)

        print("  [PASS] All Flask routes and report file generators functional (HTTP 200/400).")


if __name__ == "__main__":
    runner = unittest.TextTestRunner(verbosity=1)
    suite = unittest.TestLoader().loadTestsFromTestCase(TestNetworkDiagnostics)
    result = runner.run(suite)
    if result.wasSuccessful():
        print("\n" + "=" * 65)
        print("  ALL TESTS PASSED SUCCESSFULLY! (Project Ready for Submission)")
        print("=" * 65 + "\n")
        sys.exit(0)
    else:
        sys.exit(1)
