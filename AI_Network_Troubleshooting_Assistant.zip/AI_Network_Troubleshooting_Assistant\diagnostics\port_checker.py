"""
port_checker.py - TCP port connectivity testing.
Uses Python's socket library for safe, reliable port checks.
"""

import socket
import re
import time
from datetime import datetime


_DANGEROUS_CHARS = set(';&|`$(){}[]<>\'"\\')

# Common service names by port number
_SERVICE_NAMES = {
    21: "FTP",
    22: "SSH",
    23: "Telnet",
    25: "SMTP",
    53: "DNS",
    67: "DHCP",
    80: "HTTP",
    110: "POP3",
    143: "IMAP",
    443: "HTTPS",
    445: "SMB",
    993: "IMAPS",
    995: "POP3S",
    1433: "MSSQL",
    3306: "MySQL",
    3389: "RDP",
    5432: "PostgreSQL",
    5900: "VNC",
    6379: "Redis",
    8080: "HTTP-Alt",
    8443: "HTTPS-Alt",
    27017: "MongoDB",
}


def validate_host(host: str) -> tuple:
    """Validate a hostname or IP. Returns (is_valid, error_message)."""
    if not host:
        return False, "Host cannot be empty."
    host = host.strip()
    if len(host) > 253:
        return False, "Host is too long."
    if any(c in _DANGEROUS_CHARS for c in host):
        return False, "Host contains invalid characters."
    if not re.match(r'^[a-zA-Z0-9.\-_]+$', host):
        return False, "Host contains unsupported characters."
    return True, ""


def validate_port(port) -> tuple:
    """Validate a port number. Returns (is_valid, error_message)."""
    try:
        port = int(port)
    except (TypeError, ValueError):
        return False, "Port must be a number."
    if port < 1 or port > 65535:
        return False, "Port must be between 1 and 65535."
    return True, ""


def get_service_name(port: int) -> str:
    """Return the common service name for a port number."""
    if port in _SERVICE_NAMES:
        return _SERVICE_NAMES[port]
    # Try Python's built-in service lookup
    try:
        return socket.getservbyport(port, "tcp").upper()
    except (OSError, OverflowError):
        return f"Port {port}"


def check_port(host: str, port: int, timeout: float = 5.0) -> dict:
    """
    Test TCP connectivity to host:port.

    Args:
        host: Hostname or IP address
        port: TCP port number (1-65535)
        timeout: Connection timeout in seconds

    Returns:
        dict with port check results. Never crashes.
    """
    timestamp = datetime.now().isoformat()

    # Validate inputs
    host_valid, host_err = validate_host(host)
    port_valid, port_err = validate_port(port)

    if not host_valid:
        return {
            "success": False, "host": host, "port": port,
            "connection_time_ms": None, "error": host_err,
            "service_name": "Unknown", "timestamp": timestamp,
        }
    if not port_valid:
        return {
            "success": False, "host": host, "port": port,
            "connection_time_ms": None, "error": port_err,
            "service_name": "Unknown", "timestamp": timestamp,
        }

    host = host.strip()
    port = int(port)
    timeout = max(0.5, min(float(timeout), 30.0))  # clamp to 0.5-30s
    service_name = get_service_name(port)

    result = {
        "success": False,
        "host": host,
        "port": port,
        "connection_time_ms": None,
        "error": None,
        "service_name": service_name,
        "timestamp": timestamp,
    }

    try:
        start = time.perf_counter()
        with socket.create_connection((host, port), timeout=timeout) as sock:
            elapsed = (time.perf_counter() - start) * 1000
            result["success"] = True
            result["connection_time_ms"] = round(elapsed, 2)

    except socket.timeout:
        result["error"] = (
            f"Connection to {host}:{port} timed out after {timeout:.1f}s. "
            "The port may be filtered by a firewall."
        )
    except ConnectionRefusedError:
        result["error"] = (
            f"Connection refused at {host}:{port}. "
            "The host is reachable but no service is listening on this port."
        )
    except socket.gaierror as e:
        result["error"] = f"Could not resolve hostname '{host}': {str(e)}"
    except OSError as e:
        result["error"] = f"Network error: {str(e)}"
    except Exception as e:
        result["error"] = f"Unexpected error: {str(e)}"

    return result


def get_common_ports() -> list:
    """Return a list of common TCP ports with their service names."""
    return [
        {"port": 80, "service": "HTTP", "description": "Web traffic (unencrypted)"},
        {"port": 443, "service": "HTTPS", "description": "Web traffic (encrypted/TLS)"},
        {"port": 22, "service": "SSH", "description": "Secure Shell remote access"},
        {"port": 21, "service": "FTP", "description": "File Transfer Protocol"},
        {"port": 25, "service": "SMTP", "description": "Email sending"},
        {"port": 53, "service": "DNS", "description": "Domain Name System"},
        {"port": 3389, "service": "RDP", "description": "Remote Desktop Protocol"},
        {"port": 8080, "service": "HTTP-Alt", "description": "Alternate HTTP port"},
        {"port": 3306, "service": "MySQL", "description": "MySQL database"},
        {"port": 5432, "service": "PostgreSQL", "description": "PostgreSQL database"},
        {"port": 1433, "service": "MSSQL", "description": "Microsoft SQL Server"},
        {"port": 6379, "service": "Redis", "description": "Redis in-memory database"},
    ]


def check_multiple_ports(host: str, ports: list) -> list:
    """
    Check multiple ports on the same host sequentially.

    Args:
        host: Target hostname or IP
        ports: List of port numbers to check

    Returns:
        List of check_port result dicts.
    """
    results = []
    for port in ports:
        try:
            port_int = int(port)
        except (TypeError, ValueError):
            results.append({
                "success": False, "host": host, "port": port,
                "connection_time_ms": None,
                "error": f"Invalid port: {port}",
                "service_name": "Unknown",
                "timestamp": datetime.now().isoformat(),
            })
            continue
        results.append(check_port(host, port_int))
    return results


if __name__ == "__main__":
    import json
    print("Checking port 80 on google.com ...")
    r = check_port("google.com", 80)
    print(json.dumps(r, indent=2))

    print("\nChecking port 22 on google.com ...")
    r2 = check_port("google.com", 22, timeout=3.0)
    print(json.dumps(r2, indent=2))

    print("\nCommon ports:")
    for p in get_common_ports():
        print(f"  {p['port']:5d}  {p['service']:<12}  {p['description']}")
