"""
dns_lookup.py - DNS resolution and lookup utilities.
Uses Python's standard socket library. No external dependencies.
"""

import socket
import subprocess
import platform
import re
import time
from datetime import datetime


_DANGEROUS_CHARS = set(';&|`$(){}[]<>\'"\\')


def validate_domain(domain: str) -> tuple:
    """
    Validate a domain name string.

    Returns (True, "") if valid, (False, error_message) if not.
    """
    if not domain:
        return False, "Domain name cannot be empty."

    domain = domain.strip()

    if len(domain) > 253:
        return False, "Domain name is too long (max 253 characters)."

    if any(c in _DANGEROUS_CHARS for c in domain):
        return False, "Domain name contains invalid characters."

    # Allow letters, digits, dots, hyphens (valid hostname chars)
    if not re.match(r'^[a-zA-Z0-9.\-]+$', domain):
        return False, "Domain name contains unsupported characters."

    return True, ""


def get_dns_servers() -> list:
    """
    Returns a list of DNS server IP addresses configured on this machine.
    Uses ipconfig /all on Windows. Falls back to empty list on error.
    """
    servers = []
    try:
        if platform.system() == "Windows":
            proc = subprocess.run(
                ["ipconfig", "/all"],
                capture_output=True,
                text=True,
                timeout=10,
                encoding="utf-8",
                errors="replace",
            )
            if proc.returncode == 0:
                # Find all DNS server lines
                matches = re.findall(
                    r"DNS Servers[.\s]+:\s*([\d.]+)", proc.stdout
                )
                # Also catch additional DNS IPs on continuation lines
                # Pattern: lines that start with spaces and contain only an IP
                extra = re.findall(
                    r"(?<=DNS Servers.*\n)(?:\s{20,})([\d.]+)",
                    proc.stdout
                )
                servers = list(dict.fromkeys(matches + extra))  # deduplicate
        else:
            # Try /etc/resolv.conf on Linux/macOS
            with open("/etc/resolv.conf", "r") as f:
                for line in f:
                    m = re.match(r"^nameserver\s+([\d.]+)", line.strip())
                    if m:
                        servers.append(m.group(1))
    except Exception:
        pass

    return servers


def run_dns_lookup(domain: str) -> dict:
    """
    Perform a DNS lookup for the given domain.

    Args:
        domain: Domain name to resolve

    Returns:
        dict with lookup results. Never crashes.
    """
    timestamp = datetime.now().isoformat()

    is_valid, error_msg = validate_domain(domain)
    if not is_valid:
        return {
            "success": False,
            "domain": domain,
            "resolved_ips": [],
            "resolution_time_ms": None,
            "record_type": None,
            "reverse_lookup_ip": None,
            "error": error_msg,
            "timestamp": timestamp,
        }

    domain = domain.strip()

    result = {
        "success": False,
        "domain": domain,
        "resolved_ips": [],
        "resolution_time_ms": None,
        "record_type": "A",
        "reverse_lookup_ip": None,
        "error": None,
        "timestamp": timestamp,
    }

    try:
        start = time.perf_counter()
        addr_info = socket.getaddrinfo(domain, None)
        elapsed = (time.perf_counter() - start) * 1000  # ms

        result["resolution_time_ms"] = round(elapsed, 2)

        # Extract unique IPs (both IPv4 and IPv6)
        ips = []
        has_ipv6 = False
        for info in addr_info:
            ip = info[4][0]
            if ip not in ips:
                ips.append(ip)
            if ":" in ip:
                has_ipv6 = True

        result["resolved_ips"] = ips

        if ips:
            result["success"] = True
            result["record_type"] = "AAAA/A" if has_ipv6 else "A"

        # Reverse DNS lookup on first IPv4 address
        for ip in ips:
            if "." in ip:  # IPv4
                try:
                    rev = socket.gethostbyaddr(ip)
                    result["reverse_lookup_ip"] = rev[0]
                except Exception:
                    result["reverse_lookup_ip"] = None
                break

    except socket.gaierror as e:
        code = e.args[0] if e.args else "unknown"
        msg = e.args[1] if len(e.args) > 1 else str(e)

        if "getaddrinfo failed" in str(e) or "Name or service not known" in str(e):
            result["error"] = (
                f"DNS resolution failed for '{domain}'. "
                f"The domain may not exist or DNS servers may be unreachable. "
                f"(Error {code}: {msg})"
            )
        elif "Temporary failure in name resolution" in str(e):
            result["error"] = (
                f"Temporary DNS failure. Your DNS server may be down or unreachable. "
                f"(Error {code}: {msg})"
            )
        else:
            result["error"] = f"DNS error: {msg} (code {code})"

    except socket.timeout:
        result["error"] = "DNS lookup timed out."
    except Exception as e:
        result["error"] = f"Unexpected error during DNS lookup: {str(e)}"

    return result


if __name__ == "__main__":
    import json
    print("DNS lookup for google.com:")
    r = run_dns_lookup("google.com")
    print(json.dumps(r, indent=2))

    print("\nDNS servers on this machine:")
    print(get_dns_servers())
