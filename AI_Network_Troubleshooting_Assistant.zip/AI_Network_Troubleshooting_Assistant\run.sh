#!/usr/bin/env bash
# AI Network Troubleshooting Assistant - Linux/macOS Launcher

echo "======================================================================"
echo "         AI NETWORK TROUBLESHOOTING ASSISTANT"
echo "              Computer Networks Mini-Project"
echo "======================================================================"
echo ""

# Find Python 3
if command -v python3 &>/dev/null; then
    PYTHON_CMD=python3
elif command -v python &>/dev/null; then
    PYTHON_CMD=python
else
    echo "[ERROR] Python 3 was not found. Please install Python 3.8+."
    exit 1
fi

echo "[*] Using: $($PYTHON_CMD --version)"

# Set up venv if not present
if [ ! -d "venv" ]; then
    echo "[*] Creating virtual environment..."
    $PYTHON_CMD -m venv venv
fi

if [ -f "venv/bin/activate" ]; then
    source venv/bin/activate
    RUN_CMD=python
else
    RUN_CMD=$PYTHON_CMD
fi

echo "[*] Installing dependencies from requirements.txt..."
$RUN_CMD -m pip install -r requirements.txt --quiet

echo ""
echo "======================================================================"
echo "[*] Starting Flask Application at http://localhost:5000"
echo "[*] Press Ctrl+C to stop"
echo "======================================================================"
echo ""

$RUN_CMD app.py
