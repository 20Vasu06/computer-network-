/**
 * app.js — AI Network Troubleshooting Assistant
 * Complete frontend logic: navigation, API calls, result rendering.
 */

"use strict";

// ══════════════════════════════════════════════════════════════
// State
// ══════════════════════════════════════════════════════════════
const AppState = {
  networkInfo:        null,
  pingResult:         null,
  dnsResult:          null,
  tracerouteResult:   null,
  portResult:         null,
  pingGatewayResult:  null,
  pingInternetResult: null,
  analysisResult:     null,
  recentResults:      [],
};

// ══════════════════════════════════════════════════════════════
// Utilities
// ══════════════════════════════════════════════════════════════

function $(id) { return document.getElementById(id); }

function setText(id, text) {
  const el = $(id);
  if (el) el.textContent = text ?? "—";
}

function showEl(id)  { const e = $(id); if (e) e.classList.remove("hidden"); }
function hideEl(id)  { const e = $(id); if (e) e.classList.add("hidden"); }

function addClass(id, cls)    { const e = $(id); if (e) e.classList.add(cls); }
function removeClass(id, cls) { const e = $(id); if (e) e.classList.remove(cls); }

/** POST JSON to API endpoint, return parsed JSON or throw. */
async function apiPost(url, body = {}) {
  const resp = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  const data = await resp.json();
  if (!resp.ok) throw new Error(data.error || `HTTP ${resp.status}`);
  return data;
}

async function apiGet(url) {
  const resp = await fetch(url);
  const data = await resp.json();
  if (!resp.ok) throw new Error(data.error || `HTTP ${resp.status}`);
  return data;
}

function fmtMs(val) {
  if (val === null || val === undefined) return "—";
  return `${Number(val).toFixed(1)} ms`;
}

function fmtPct(val) {
  if (val === null || val === undefined) return "—";
  return `${Number(val).toFixed(1)}%`;
}

function timeNow() {
  return new Date().toLocaleTimeString();
}

/** Add a recent result entry to the dashboard list. */
function addRecentResult(label, status, detail) {
  AppState.recentResults.unshift({ label, status, detail, time: timeNow() });
  if (AppState.recentResults.length > 20) AppState.recentResults.pop();
  renderRecentResults();
  updateReportSummary();
}

function renderRecentResults() {
  const container = $("recent-results-list");
  if (!container) return;
  if (AppState.recentResults.length === 0) {
    container.innerHTML = `<div class="empty-state"><span class="empty-icon">📊</span><p>No diagnostics run yet.</p></div>`;
    return;
  }
  container.innerHTML = AppState.recentResults.map(r => {
    const statusClass = r.status === "success" ? "success" : r.status === "warn" ? "warn" : "danger";
    const statusText = r.status === "success" ? "✓" : r.status === "warn" ? "⚠" : "✗";
    return `
      <div class="recent-item">
        <span class="recent-label">${escHtml(r.label)}</span>
        <span class="recent-value">${escHtml(r.detail)}</span>
        <span class="badge badge-${statusClass}">${statusText} ${r.status}</span>
        <span class="text-secondary">${r.time}</span>
      </div>`;
  }).join("");
}

function escHtml(str) {
  if (!str) return "";
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

// ══════════════════════════════════════════════════════════════
// Toast Notifications
// ══════════════════════════════════════════════════════════════

function showToast(message, type = "info", duration = 4000) {
  const container = $("toast-container");
  if (!container) return;
  const toast = document.createElement("div");
  toast.className = `toast ${type}`;
  toast.textContent = message;
  container.appendChild(toast);
  setTimeout(() => {
    toast.classList.add("fade-out");
    setTimeout(() => toast.remove(), 350);
  }, duration);
}

// ══════════════════════════════════════════════════════════════
// Loading Overlay
// ══════════════════════════════════════════════════════════════

function showLoading(text = "Running diagnostics...") {
  setText("loading-text", text);
  showEl("loading-overlay");
}

function hideLoading() {
  hideEl("loading-overlay");
}

// ══════════════════════════════════════════════════════════════
// Navigation
// ══════════════════════════════════════════════════════════════

const PAGE_TITLES = {
  "dashboard":    "Dashboard",
  "network-info": "Network Information",
  "ping":         "Ping Test",
  "dns":          "DNS Lookup",
  "traceroute":   "Traceroute",
  "port":         "Port Checker",
  "ai-assistant": "AI Assistant",
  "reports":      "Reports",
};

function navigateTo(pageId) {
  // Hide all pages
  document.querySelectorAll(".page").forEach(p => p.classList.remove("active"));
  document.querySelectorAll(".nav-item").forEach(n => n.classList.remove("active"));

  // Show target page
  const page = $(`page-${pageId}`);
  if (page) page.classList.add("active");

  // Activate nav item
  const navItem = document.querySelector(`.nav-item[data-page="${pageId}"]`);
  if (navItem) navItem.classList.add("active");

  // Update title
  setText("page-title", PAGE_TITLES[pageId] || "Dashboard");

  // Auto-actions on page load
  if (pageId === "network-info" && !AppState.networkInfo) {
    loadNetworkInfo();
  }
  if (pageId === "port") {
    loadCommonPorts();
  }
  if (pageId === "reports") {
    updateReportSummary();
    updateReportPreview();
  }
}

// ══════════════════════════════════════════════════════════════
// Timestamp updater
// ══════════════════════════════════════════════════════════════

function updateTimestamp() {
  const el = $("header-timestamp");
  if (el) {
    el.textContent = new Date().toLocaleString();
  }
}

// ══════════════════════════════════════════════════════════════
// Dashboard
// ══════════════════════════════════════════════════════════════

function updateDashboardFromNetworkInfo(info) {
  if (!info) return;
  setText("dash-ip", info.local_ip || "—");
  setText("dash-gateway", info.gateway || "—");
  setText("dash-hostname", info.hostname || "—");

  const hasIp = info.local_ip && info.local_ip !== "Unavailable";
  setText("dash-status", hasIp ? "Connected" : "No Connection");

  const badge = $("connection-badge");
  if (badge) {
    badge.textContent = hasIp ? "Connected" : "No Connection";
    badge.className = `badge ${hasIp ? "badge-success" : "badge-danger"}`;
  }
}

function updateDashboardLatency(pingResult) {
  if (!pingResult) return;
  const avg = pingResult.avg_latency_ms;
  const loss = pingResult.packet_loss_pct || 0;

  if (avg !== null && avg !== undefined) {
    setText("dash-latency", avg.toFixed(0));
    const pct = Math.min((avg / 500) * 100, 100);
    const bar = $("dash-latency-bar");
    if (bar) bar.style.width = pct + "%";
    setText("dash-latency-desc", `${avg.toFixed(1)} ms avg RTT to ${pingResult.target}`);
  }

  setText("dash-pktloss", loss.toFixed(1));
  const lossBar = $("dash-pktloss-bar");
  if (lossBar) lossBar.style.width = loss + "%";
  setText("dash-pktloss-desc", `${loss.toFixed(1)}% packet loss to ${pingResult.target}`);
}

function updateDashboardHealth(analysis) {
  if (!analysis) return;
  const score = analysis.health_score;
  setText("dash-health", score);
  const bar = $("dash-health-bar");
  if (bar) bar.style.width = score + "%";
  setText("dash-health-desc", `${analysis.overall_health} — ${analysis.issues.length} issue(s) found`);
}

// ══════════════════════════════════════════════════════════════
// Network Info
// ══════════════════════════════════════════════════════════════

async function loadNetworkInfo() {
  showEl("netinfo-loading");
  hideEl("netinfo-results");
  hideEl("netinfo-error");

  try {
    const data = await apiGet("/api/network-info");
    AppState.networkInfo = data;

    setText("ni-hostname",  data.hostname  || "—");
    setText("ni-ip",        data.local_ip  || "—");
    setText("ni-subnet",    data.subnet_mask || "—");
    setText("ni-gateway",   data.gateway   || "—");
    setText("ni-interface", data.interface_name || "—");
    setText("ni-dns",       (data.dns_servers || []).join(", ") || "—");
    setText("ni-mac",       data.mac_address || "—");
    setText("ni-dhcp",      data.dhcp_enabled || "—");
    setText("ni-conntype",  data.connection_type || "—");
    setText("ni-os",        data.os || "—");

    const summary = $("ni-summary");
    if (summary) {
      summary.textContent = data.connection_summary || "";
      summary.classList.toggle("hidden", !data.connection_summary);
    }

    updateDashboardFromNetworkInfo(data);

    hideEl("netinfo-loading");
    showEl("netinfo-results");
    showToast("Network information loaded", "success");
    addRecentResult("Network Info", "success", data.connection_summary || data.local_ip);
  } catch (err) {
    hideEl("netinfo-loading");
    const errEl = $("netinfo-error");
    if (errEl) {
      errEl.textContent = `Error: ${err.message}`;
      showEl("netinfo-error");
    }
    showToast(`Network info failed: ${err.message}`, "error");
  }
}

// ══════════════════════════════════════════════════════════════
// Ping Test
// ══════════════════════════════════════════════════════════════

async function runPing(target, count) {
  target = target || $("ping-target").value.trim();
  count  = count  || parseInt($("ping-count").value) || 4;

  if (!target) { showToast("Please enter a target", "warn"); return; }

  const btn = $("btn-ping");
  if (btn) { btn.disabled = true; btn.textContent = "Running..."; }

  hideEl("ping-results-section");
  hideEl("ping-error-box");

  try {
    const data = await apiPost("/api/ping", { target, count });
    AppState.pingResult = data;
    renderPingResults(data);
    updateDashboardLatency(data);
    addRecentResult(
      `Ping → ${data.target}`,
      data.success ? "success" : "error",
      data.success
        ? `Avg ${fmtMs(data.avg_latency_ms)}, Loss ${fmtPct(data.packet_loss_pct)}`
        : (data.error || "Failed")
    );
  } catch (err) {
    showToast(`Ping error: ${err.message}`, "error");
  } finally {
    if (btn) { btn.disabled = false; btn.textContent = "▶ Run Ping"; }
  }
}

function renderPingResults(data) {
  showEl("ping-results-section");

  const isSuccess = data.success;
  const badge = $("ping-status-badge");
  if (badge) {
    badge.textContent = isSuccess ? "✓ Success" : "✗ Failed";
    badge.className   = `badge ${isSuccess ? "badge-success" : "badge-danger"}`;
  }

  setText("ping-result-target", data.target);
  setText("ping-min", data.min_latency_ms != null ? data.min_latency_ms.toFixed(1) : "—");
  setText("ping-avg", data.avg_latency_ms != null ? data.avg_latency_ms.toFixed(1) : "—");
  setText("ping-max", data.max_latency_ms != null ? data.max_latency_ms.toFixed(1) : "—");
  setText("ping-loss", data.packet_loss_pct != null ? data.packet_loss_pct.toFixed(1) : "—");
  setText("ping-pkt-ratio", `${data.packets_received}/${data.packets_sent}`);

  // Packet loss bar
  const loss = data.packet_loss_pct || 0;
  const bar = $("ping-loss-bar");
  if (bar) {
    bar.style.width = loss + "%";
    bar.style.background = loss === 0 ? "var(--success)"
                         : loss < 10  ? "var(--warn)"
                         : "var(--danger)";
  }
  setText("ping-loss-pct-label", `${loss.toFixed(1)}%`);

  // Error box
  const errBox = $("ping-error-box");
  if (errBox) {
    if (data.error) {
      errBox.textContent = `⚠ ${data.error}`;
      showEl("ping-error-box");
    } else {
      hideEl("ping-error-box");
    }
  }

  setText("ping-raw-output", data.raw_output || "(no output)");
}

// ══════════════════════════════════════════════════════════════
// DNS Lookup
// ══════════════════════════════════════════════════════════════

async function runDnsLookup(domain) {
  domain = domain || $("dns-domain").value.trim();
  if (!domain) { showToast("Please enter a domain name", "warn"); return; }

  const btn = $("btn-dns");
  if (btn) { btn.disabled = true; btn.textContent = "Looking up..."; }

  hideEl("dns-results-section");

  try {
    const data = await apiPost("/api/dns-lookup", { domain });
    AppState.dnsResult = data;
    renderDnsResults(data);
    addRecentResult(
      `DNS → ${data.domain}`,
      data.success ? "success" : "error",
      data.success
        ? `${(data.resolved_ips || []).slice(0,2).join(", ")} (${fmtMs(data.resolution_time_ms)})`
        : (data.error || "Failed")
    );
  } catch (err) {
    showToast(`DNS lookup error: ${err.message}`, "error");
  } finally {
    if (btn) { btn.disabled = false; btn.textContent = "🔍 Lookup"; }
  }
}

function renderDnsResults(data) {
  showEl("dns-results-section");

  const badge = $("dns-status-badge");
  if (badge) {
    badge.textContent = data.success ? "✓ Resolved" : "✗ Failed";
    badge.className   = `badge ${data.success ? "badge-success" : "badge-danger"}`;
  }

  setText("dns-result-domain", data.domain);
  setText("dns-time", data.resolution_time_ms != null ? `${data.resolution_time_ms.toFixed(2)} ms` : "—");
  setText("dns-record-type", data.record_type || "—");
  setText("dns-reverse", data.reverse_lookup_ip || "—");
  setText("dns-servers-list", (data.dns_servers || []).join(", ") || "—");

  const ipList = $("dns-ips");
  if (ipList) {
    if (data.resolved_ips && data.resolved_ips.length > 0) {
      ipList.innerHTML = data.resolved_ips.map(ip =>
        `<span class="ip-tag">${escHtml(ip)}</span>`
      ).join("");
    } else {
      ipList.innerHTML = "<span class='text-secondary'>—</span>";
    }
  }

  const errBox = $("dns-error-box");
  if (errBox) {
    if (data.error) {
      errBox.textContent = `⚠ ${data.error}`;
      showEl("dns-error-box");
    } else {
      hideEl("dns-error-box");
    }
  }
}

// ══════════════════════════════════════════════════════════════
// Traceroute
// ══════════════════════════════════════════════════════════════

async function runTraceroute(target) {
  target = target || $("traceroute-target").value.trim();
  if (!target) { showToast("Please enter a target", "warn"); return; }

  const btn = $("btn-traceroute");
  if (btn) { btn.disabled = true; btn.textContent = "Tracing..."; }

  showLoading("Running traceroute... this may take up to 2 minutes");
  hideEl("traceroute-results-section");

  try {
    const data = await apiPost("/api/traceroute", { target });
    AppState.tracerouteResult = data;
    renderTracerouteResults(data);
    addRecentResult(
      `Traceroute → ${data.target}`,
      data.success ? (data.reached_destination ? "success" : "warn") : "error",
      data.success
        ? `${data.total_hops} hops, ${data.reached_destination ? "reached" : "not reached"}`
        : (data.error || "Failed")
    );
  } catch (err) {
    showToast(`Traceroute error: ${err.message}`, "error");
  } finally {
    hideLoading();
    if (btn) { btn.disabled = false; btn.textContent = "🗺️ Trace Route"; }
  }
}

function latencyClass(ms) {
  if (ms === null || ms === undefined) return "";
  if (ms < 50)  return "fast";
  if (ms < 150) return "med";
  return "slow";
}

function renderTracerouteResults(data) {
  showEl("traceroute-results-section");

  setText("traceroute-result-target", data.target);
  setText("trace-total-hops", data.total_hops || "—");
  setText("trace-reached", data.reached_destination ? "Yes" : "No");

  const statusBadge = $("traceroute-status-badge");
  if (statusBadge) {
    statusBadge.textContent = data.success ? "✓ Success" : "✗ Failed";
    statusBadge.className   = `badge ${data.success ? "badge-success" : "badge-danger"}`;
  }

  const destBadge = $("traceroute-dest-badge");
  if (destBadge) {
    destBadge.textContent = data.reached_destination ? "✓ Reached" : "✗ Not Reached";
    destBadge.className   = `badge ${data.reached_destination ? "badge-success" : "badge-warn"}`;
  }

  // Build hop table rows
  const tbody = $("traceroute-tbody");
  if (tbody) {
    if (!data.hops || data.hops.length === 0) {
      tbody.innerHTML = `<tr><td colspan="7" class="empty-cell">No hops recorded</td></tr>`;
    } else {
      tbody.innerHTML = data.hops.map(hop => {
        const isTimeout = hop.is_timeout;
        const lats = hop.latencies || [null, null, null];
        const avg = hop.avg_latency_ms;
        const cls = isTimeout ? "hop-row-timeout" : "hop-row-ok";
        const latCells = lats.map(l => {
          if (l === null || l === undefined) return `<td class="hop-lat">*</td>`;
          return `<td class="hop-lat ${latencyClass(l)}">${l.toFixed(1)} ms</td>`;
        }).join("");
        const avgCell = avg != null ? `<span class="hop-lat ${latencyClass(avg)}">${avg.toFixed(1)} ms</span>` : "—";
        const statusCell = isTimeout ? "⚠ Timeout" : "✓";
        return `
          <tr class="${cls}">
            <td>${hop.hop_num}</td>
            <td class="hop-ip">${escHtml(hop.ip)}</td>
            ${latCells}
            <td>${avgCell}</td>
            <td>${statusCell}</td>
          </tr>`;
      }).join("");
    }
  }

  // Error box
  const errBox = $("traceroute-error-box");
  if (errBox) {
    if (data.error) {
      errBox.textContent = `⚠ ${data.error}`;
      showEl("traceroute-error-box");
    } else {
      hideEl("traceroute-error-box");
    }
  }

  setText("traceroute-raw-output", data.raw_output || "(no output)");
}

// ══════════════════════════════════════════════════════════════
// Port Checker
// ══════════════════════════════════════════════════════════════

async function loadCommonPorts() {
  try {
    const ports = await apiGet("/api/common-ports");
    renderCommonPorts(ports);
  } catch (e) {
    // non-critical failure
  }
}

function renderCommonPorts(ports) {
  const grid = $("common-ports-grid");
  if (!grid) return;
  grid.innerHTML = ports.map(p => `
    <button class="port-chip" data-port="${p.port}" title="${escHtml(p.description)}">
      <span class="port-chip-num">${p.port}</span>
      <span class="port-chip-name">${escHtml(p.service)}</span>
    </button>
  `).join("");

  grid.querySelectorAll(".port-chip").forEach(chip => {
    chip.addEventListener("click", () => {
      const portInput = $("port-port");
      if (portInput) portInput.value = chip.dataset.port;
    });
  });
}

async function runPortCheck(host, port, timeout) {
  host    = host    || $("port-host").value.trim();
  port    = port    || parseInt($("port-port").value);
  timeout = timeout || parseFloat($("port-timeout").value) || 5;

  if (!host) { showToast("Please enter a host", "warn"); return; }
  if (!port || port < 1 || port > 65535) { showToast("Invalid port number (1–65535)", "warn"); return; }

  const btn = $("btn-port-check");
  if (btn) { btn.disabled = true; btn.textContent = "Checking..."; }

  hideEl("port-results-section");

  try {
    const data = await apiPost("/api/port-check", { host, port, timeout });
    AppState.portResult = data;
    renderPortResults(data);
    addRecentResult(
      `Port → ${data.host}:${data.port}`,
      data.success ? "success" : "error",
      data.success
        ? `Open (${fmtMs(data.connection_time_ms)}) — ${data.service_name}`
        : (data.error || "Closed/Filtered")
    );
  } catch (err) {
    showToast(`Port check error: ${err.message}`, "error");
  } finally {
    if (btn) { btn.disabled = false; btn.textContent = "🔌 Check Port"; }
  }
}

function renderPortResults(data) {
  showEl("port-results-section");

  const badge = $("port-status-badge");
  if (badge) {
    badge.textContent = data.success ? "✓ Open" : "✗ Closed/Filtered";
    badge.className   = `badge ${data.success ? "badge-success" : "badge-danger"}`;
  }

  setText("port-result-label", `${data.host}:${data.port} (${data.service_name})`);
  setText("port-res-host", data.host);
  setText("port-res-port", data.port);
  setText("port-res-service", data.service_name || "—");
  setText("port-res-time", data.connection_time_ms != null ? data.connection_time_ms.toFixed(2) : "—");

  const errBox = $("port-error-box");
  if (errBox) {
    if (data.error) {
      errBox.textContent = `⚠ ${data.error}`;
      showEl("port-error-box");
    } else {
      hideEl("port-error-box");
    }
  }
}

// ══════════════════════════════════════════════════════════════
// AI Assistant
// ══════════════════════════════════════════════════════════════

async function runAutoDiagnose() {
  const btn = $("btn-auto-diagnose");
  if (btn) { btn.disabled = true; btn.textContent = "⚡ Running..."; }

  showLoading("Running auto-diagnosis (ping + DNS + analysis)...");
  hideEl("ai-results-section");

  try {
    const data = await apiPost("/api/quick-diagnose", {});

    // Store results
    if (data.network_info)        AppState.networkInfo        = data.network_info;
    if (data.ping_gateway_result) AppState.pingGatewayResult  = data.ping_gateway_result;
    if (data.ping_internet_result) AppState.pingInternetResult = data.ping_internet_result;
    if (data.dns_result)          AppState.dnsResult          = data.dns_result;
    if (data.analysis)            AppState.analysisResult     = data.analysis;

    // Update dashboard
    if (data.network_info)        updateDashboardFromNetworkInfo(data.network_info);
    if (data.ping_internet_result) updateDashboardLatency(data.ping_internet_result);
    if (data.analysis)            updateDashboardHealth(data.analysis);

    renderAnalysisResults(data.analysis);
    showToast("Auto-diagnosis complete", "success");
    addRecentResult("Auto-Diagnose", "success",
      `Health: ${data.analysis?.overall_health || "?"} (${data.analysis?.health_score || "?"}/100)`);

  } catch (err) {
    showToast(`Diagnosis failed: ${err.message}`, "error");
  } finally {
    hideLoading();
    if (btn) { btn.disabled = false; btn.textContent = "⚡ Quick Auto-Diagnose"; }
  }
}

function renderAnalysisResults(analysis) {
  if (!analysis) return;
  showEl("ai-results-section");

  const score = analysis.health_score;
  setText("health-score-num", score);
  setText("health-overall", analysis.overall_health);
  setText("health-summary", analysis.summary || "");

  // Health circle color
  const circle = $("health-score-circle");
  if (circle) {
    circle.classList.remove("poor", "bad");
    if (score < 30) circle.classList.add("bad");
    else if (score < 60) circle.classList.add("poor");
  }

  // Render issue cards
  const container = $("ai-issues-container");
  if (container) {
    if (!analysis.issues || analysis.issues.length === 0) {
      container.innerHTML = "";
    } else {
      container.innerHTML = analysis.issues.map(issue => {
        const sevColor = {
          critical: "badge-danger", high: "badge-warn",
          medium: "badge-warn", low: "badge-info", info: "badge-success"
        }[issue.severity] || "badge-info";

        const steps = (issue.recommended_solution || []).map(s =>
          `<li>${escHtml(s)}</li>`
        ).join("");

        return `
          <div class="issue-card sev-${escHtml(issue.severity)}">
            <div class="issue-header">
              <span class="issue-title">${escHtml(issue.title)}</span>
              <span class="badge ${sevColor}">${escHtml(issue.severity)}</span>
            </div>
            <div class="issue-section-label">Evidence</div>
            <div class="issue-evidence">${escHtml(issue.evidence)}</div>
            <div class="issue-section-label">Possible Cause</div>
            <div class="issue-cause">${escHtml(issue.possible_cause)}</div>
            <div class="issue-section-label">Recommended Solution</div>
            <ul class="issue-steps">${steps}</ul>
            <div style="margin-top:8px">
              <span class="text-secondary">Affected: ${escHtml(issue.affected_component)}</span>
            </div>
          </div>`;
      }).join("");
    }
  }

  // Recommendations
  const recList = $("ai-recommendations-list");
  if (recList) {
    const recs = analysis.recommendations || [];
    if (recs.length === 0) {
      showEl("ai-recommendations-card") && hideEl("ai-recommendations-card");
    } else {
      showEl("ai-recommendations-card");
      recList.innerHTML = recs.map(r => `<li>${escHtml(r)}</li>`).join("");
    }
  }
}

// ══════════════════════════════════════════════════════════════
// Reports
// ══════════════════════════════════════════════════════════════

function getAllResultsForReport() {
  return {
    network_info:         AppState.networkInfo,
    ping_gateway_result:  AppState.pingGatewayResult,
    ping_internet_result: AppState.pingInternetResult,
    ping_result:          AppState.pingResult,
    dns_result:           AppState.dnsResult,
    traceroute_result:    AppState.tracerouteResult,
    port_result:          AppState.portResult,
    analysis:             AppState.analysisResult,
  };
}

async function downloadReport(fmt) {
  const data = getAllResultsForReport();
  try {
    const resp = await fetch("/api/download-report", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ format: fmt, data }),
    });

    if (!resp.ok) {
      const err = await resp.json();
      throw new Error(err.error || "Download failed");
    }

    const blob = await resp.blob();
    const url  = URL.createObjectURL(blob);
    const a    = document.createElement("a");
    const ts   = new Date().toISOString().replace(/[:.]/g, "-").slice(0, 19);
    a.href     = url;
    a.download = `network_report_${ts}.${fmt}`;
    a.click();
    URL.revokeObjectURL(url);
    showToast(`Report downloaded as .${fmt}`, "success");
  } catch (err) {
    showToast(`Download failed: ${err.message}`, "error");
  }
}

function updateReportSummary() {
  const tbody = $("report-summary-tbody");
  if (!tbody) return;

  const rows = [];

  function addRow(name, result, getStatus, getDetail) {
    if (!result) return;
    const status = getStatus(result);
    const detail = getDetail(result);
    const ts = result.timestamp ? new Date(result.timestamp).toLocaleTimeString() : "—";
    const cls = status === "success" ? "badge-success" : "badge-danger";
    rows.push(`
      <tr>
        <td>${name}</td>
        <td><span class="badge ${cls}">${status}</span></td>
        <td>${escHtml(detail)}</td>
        <td>${ts}</td>
      </tr>
    `);
  }

  if (AppState.networkInfo) {
    rows.push(`<tr>
      <td>Network Info</td>
      <td><span class="badge badge-success">collected</span></td>
      <td>${escHtml(AppState.networkInfo.local_ip || "—")}</td>
      <td>${new Date(AppState.networkInfo.timestamp).toLocaleTimeString()}</td>
    </tr>`);
  }
  addRow("Ping (Gateway)", AppState.pingGatewayResult,
    r => r.success ? "success" : "failed",
    r => r.success ? `${r.avg_latency_ms?.toFixed(1) || "?"}ms avg` : (r.error || "failed"));
  addRow("Ping (Internet)", AppState.pingInternetResult,
    r => r.success ? "success" : "failed",
    r => r.success ? `${r.avg_latency_ms?.toFixed(1) || "?"}ms avg` : (r.error || "failed"));
  addRow("Ping", AppState.pingResult,
    r => r.success ? "success" : "failed",
    r => r.success ? `${r.avg_latency_ms?.toFixed(1) || "?"}ms avg` : (r.error || "failed"));
  addRow("DNS Lookup", AppState.dnsResult,
    r => r.success ? "success" : "failed",
    r => r.success ? (r.resolved_ips || []).slice(0,1).join("") : (r.error || "failed"));
  addRow("Traceroute", AppState.tracerouteResult,
    r => r.success ? "success" : "failed",
    r => r.success ? `${r.total_hops} hops` : (r.error || "failed"));
  addRow("Port Check", AppState.portResult,
    r => r.success ? "success" : "failed",
    r => r.success ? `${r.host}:${r.port} open` : (r.error || "closed"));

  if (rows.length === 0) {
    tbody.innerHTML = `<tr id="report-empty-row"><td colspan="4" class="empty-cell">No tests have been run yet.</td></tr>`;
  } else {
    tbody.innerHTML = rows.join("");
  }
}

function updateReportPreview() {
  const pre = $("report-preview-content");
  const ts  = $("report-preview-ts");
  if (!pre) return;

  const hasData = Object.values(AppState).some(v => v !== null && typeof v === "object");
  if (!hasData) {
    pre.textContent = "Run diagnostic tests to generate a report preview.";
    return;
  }

  if (ts) ts.textContent = `Generated: ${new Date().toLocaleString()}`;

  const data = getAllResultsForReport();
  const lines = [];
  lines.push("=" .repeat(60));
  lines.push("  AI NETWORK TROUBLESHOOTING ASSISTANT — Diagnostic Report");
  lines.push(`  Generated: ${new Date().toLocaleString()}`);
  lines.push("=".repeat(60));
  lines.push("");

  const net = data.network_info;
  if (net) {
    lines.push("── NETWORK INFORMATION ──────────────────────────────────");
    lines.push(`  Hostname       : ${net.hostname || "—"}`);
    lines.push(`  Local IP       : ${net.local_ip || "—"}`);
    lines.push(`  Subnet Mask    : ${net.subnet_mask || "—"}`);
    lines.push(`  Default Gateway: ${net.gateway || "—"}`);
    lines.push(`  DNS Servers    : ${(net.dns_servers || []).join(", ") || "—"}`);
    lines.push(`  Connection     : ${net.connection_type || "—"}`);
    lines.push("");
  }

  for (const [key, label] of [
    ["ping_gateway_result",  "PING — GATEWAY"],
    ["ping_internet_result", "PING — INTERNET"],
    ["ping_result",          "PING TEST"],
  ]) {
    const ping = data[key];
    if (ping) {
      lines.push(`── ${label} ${"─".repeat(55 - label.length)}`);
      lines.push(`  Target  : ${ping.target}`);
      lines.push(`  Status  : ${ping.success ? "SUCCESS" : "FAILED"}`);
      lines.push(`  Avg RTT : ${fmtMs(ping.avg_latency_ms)}`);
      lines.push(`  Loss    : ${fmtPct(ping.packet_loss_pct)}`);
      if (ping.error) lines.push(`  Error   : ${ping.error}`);
      lines.push("");
    }
  }

  const dns = data.dns_result;
  if (dns) {
    lines.push("── DNS LOOKUP ───────────────────────────────────────────");
    lines.push(`  Domain         : ${dns.domain}`);
    lines.push(`  Status         : ${dns.success ? "SUCCESS" : "FAILED"}`);
    lines.push(`  Resolved IPs   : ${(dns.resolved_ips || []).join(", ") || "—"}`);
    lines.push(`  Resolution Time: ${fmtMs(dns.resolution_time_ms)}`);
    if (dns.error) lines.push(`  Error          : ${dns.error}`);
    lines.push("");
  }

  const analysis = data.analysis;
  if (analysis) {
    lines.push("── AI TROUBLESHOOTING ANALYSIS ──────────────────────────");
    lines.push(`  Overall Health : ${analysis.overall_health}`);
    lines.push(`  Health Score   : ${analysis.health_score}/100`);
    lines.push(`  Summary        : ${analysis.summary}`);
    lines.push("");
    for (const issue of (analysis.issues || [])) {
      lines.push(`  [${issue.severity.toUpperCase()}] ${issue.title}`);
      lines.push(`    Cause: ${issue.possible_cause}`);
      for (const step of (issue.recommended_solution || []).slice(0, 2)) {
        lines.push(`    ${step}`);
      }
      lines.push("");
    }
  }

  lines.push("=".repeat(60));
  lines.push("  End of Report");
  lines.push("=".repeat(60));

  pre.textContent = lines.join("\n");
}

// ══════════════════════════════════════════════════════════════
// Quick Diagnose (Dashboard button)
// ══════════════════════════════════════════════════════════════

async function runQuickDiagnose() {
  showLoading("Running auto-diagnosis...");
  try {
    const data = await apiPost("/api/quick-diagnose", {});
    if (data.network_info)         AppState.networkInfo        = data.network_info;
    if (data.ping_gateway_result)  AppState.pingGatewayResult  = data.ping_gateway_result;
    if (data.ping_internet_result) AppState.pingInternetResult = data.ping_internet_result;
    if (data.dns_result)           AppState.dnsResult          = data.dns_result;
    if (data.analysis)             AppState.analysisResult     = data.analysis;

    updateDashboardFromNetworkInfo(data.network_info);
    updateDashboardLatency(data.ping_internet_result || data.ping_gateway_result);
    updateDashboardHealth(data.analysis);

    addRecentResult("Quick Diagnose", "success",
      `Health: ${data.analysis?.overall_health} (${data.analysis?.health_score}/100)`);
    showToast("Quick diagnosis complete! Check AI Assistant for details.", "success");
  } catch (err) {
    showToast(`Quick diagnose failed: ${err.message}`, "error");
  } finally {
    hideLoading();
  }
}

// ══════════════════════════════════════════════════════════════
// Event Listeners
// ══════════════════════════════════════════════════════════════

document.addEventListener("DOMContentLoaded", () => {

  // ── Navigation ────────────────────────────────────────────
  document.querySelectorAll(".nav-item").forEach(item => {
    item.addEventListener("click", () => {
      navigateTo(item.dataset.page);
    });
  });

  // ── Sidebar toggle ────────────────────────────────────────
  const sidebarToggle = $("sidebar-toggle");
  const sidebar = $("sidebar");
  if (sidebarToggle && sidebar) {
    sidebarToggle.addEventListener("click", () => {
      sidebar.classList.toggle("collapsed");
    });
  }

  // ── Dashboard quick actions ───────────────────────────────
  $("btn-quick-diagnose")?.addEventListener("click", runQuickDiagnose);
  $("btn-dash-ping")?.addEventListener("click", () => navigateTo("ping"));
  $("btn-dash-dns")?.addEventListener("click", () => navigateTo("dns"));
  $("btn-dash-traceroute")?.addEventListener("click", () => navigateTo("traceroute"));
  $("btn-dash-port")?.addEventListener("click", () => navigateTo("port"));
  $("btn-dash-report")?.addEventListener("click", () => {
    updateReportPreview();
    navigateTo("reports");
  });
  $("btn-clear-recent")?.addEventListener("click", () => {
    AppState.recentResults = [];
    renderRecentResults();
  });

  // ── Network Info ──────────────────────────────────────────
  $("btn-refresh-netinfo")?.addEventListener("click", loadNetworkInfo);

  // ── Ping ─────────────────────────────────────────────────
  $("btn-ping")?.addEventListener("click", () => runPing());
  $("ping-target")?.addEventListener("keydown", e => { if (e.key === "Enter") runPing(); });
  document.querySelectorAll("[data-ping-target]").forEach(chip => {
    chip.addEventListener("click", () => {
      const t = chip.dataset.pingTarget;
      const inp = $("ping-target");
      if (inp) inp.value = t;
      runPing(t);
    });
  });

  // ── DNS ───────────────────────────────────────────────────
  $("btn-dns")?.addEventListener("click", () => runDnsLookup());
  $("dns-domain")?.addEventListener("keydown", e => { if (e.key === "Enter") runDnsLookup(); });
  document.querySelectorAll("[data-dns-target]").forEach(chip => {
    chip.addEventListener("click", () => {
      const d = chip.dataset.dnsTarget;
      const inp = $("dns-domain");
      if (inp) inp.value = d;
      runDnsLookup(d);
    });
  });

  // ── Traceroute ────────────────────────────────────────────
  $("btn-traceroute")?.addEventListener("click", () => runTraceroute());
  $("traceroute-target")?.addEventListener("keydown", e => { if (e.key === "Enter") runTraceroute(); });
  document.querySelectorAll("[data-traceroute-target]").forEach(chip => {
    chip.addEventListener("click", () => {
      const t = chip.dataset.tracerouteTarget;
      const inp = $("traceroute-target");
      if (inp) inp.value = t;
      runTraceroute(t);
    });
  });

  // ── Port Checker ──────────────────────────────────────────
  $("btn-port-check")?.addEventListener("click", () => runPortCheck());

  // ── AI Assistant ──────────────────────────────────────────
  $("btn-auto-diagnose")?.addEventListener("click", runAutoDiagnose);

  // ── Reports ───────────────────────────────────────────────
  $("btn-download-txt")?.addEventListener("click",  () => downloadReport("txt"));
  $("btn-download-json")?.addEventListener("click", () => downloadReport("json"));

  // ── Timestamp ─────────────────────────────────────────────
  updateTimestamp();
  setInterval(updateTimestamp, 1000);

  // ── Auto-load network info on startup ─────────────────────
  loadNetworkInfo();
});
