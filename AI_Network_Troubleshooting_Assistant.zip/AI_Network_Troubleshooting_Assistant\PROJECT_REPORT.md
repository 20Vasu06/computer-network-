# Academic Mini-Project Report
## Subject: Computer Networks (CS / IT / ECE)
### Title: AI Network Troubleshooting Assistant

---

**Academic Year:** 2024–2025  
**Course Code:** CS-CN-302 / IT-401  
**Project Category:** Computer Networks & Systems Programming  
**Technology Stack:** Python 3, Flask, HTML5, CSS3, JavaScript (ES6), Standard Socket & Subprocess APIs  
**Project Repository:** `AI_Network_Troubleshooting_Assistant`  

---

## Abstract

Network connectivity degradation, DNS lookup timeouts, firewall port restrictions, and gateway misconfigurations represent the vast majority of day-to-day computer networking failures. Diagnosing these faults typically requires executing multiple command-line utilities (`ping`, `tracert`, `nslookup`, `netstat`, `curl`) and interpreting raw binary and text telemetry. For end-users and junior network operators, correlating disparate metrics (such as Round-Trip Time, TTL expirations, and socket timeout errors) into actionable recovery steps presents a steep learning curve.

This project implements the **AI Network Troubleshooting Assistant**, a locally hosted, lightweight web application providing automated diagnostics, interactive socket-level probing, and an expert rule-based inference engine. The system requires zero external cloud dependencies or paid API keys, operating strictly in local execution environments. It demonstrates fundamental Computer Networks principles: the 4-layer TCP/IP reference model, ICMP Echo and TTL error handling, DNS recursive resolution, transport-layer TCP 3-way handshaking, port multiplexing, and routing path analysis.

---

## 1. Introduction & Problem Statement

### 1.1 Motivation
In academic and practical environments, network diagnostics are often taught as isolated CLI commands. Students frequently struggle to correlate:
1. Why an ICMP ping might succeed while an HTTP GET over port 80 fails (distinguishing between Layer 3 and Layer 4 reachability).
2. Why a machine can reach `8.8.8.8` but fail to open `google.com` (Layer 7 DNS name resolution failure vs. Layer 3 internet connectivity).
3. The distinction between a `Connection Refused` error (TCP RST received; port closed) versus a socket timeout (silent packet drop; firewall filtered).

### 1.2 Problem Statement
To design, implement, and validate an automated, safe, and intuitive software solution that:
- Gathers hardware and host configuration telemetry (IP, subnet, gateway, DNS).
- Implements active network probes across the transport and network layers without requiring elevated administrative privileges.
- Employs a deterministic, rule-based inference system to diagnose specific failure modes and output severity-ranked remediation steps.
- Exposes all capabilities through an accessible web interface and generates auditable diagnostic reports in standard text and JSON formats.

---

## 2. Theoretical Background & Computer Networks Concepts

The application serves as a concrete realization of fundamental networking theories:

```
+-------------------------------------------------------------------------+
|                        APPLICATION LAYER (Layer 4/7)                    |
|   - Flask HTTP Server (Port 5000)                                       |
|   - DNS Name Resolution (UDP/TCP Port 53 via getaddrinfo)               |
+-------------------------------------------------------------------------+
                                    │
+-------------------------------------------------------------------------+
|                        TRANSPORT LAYER (Layer 3/4)                      |
|   - TCP 3-Way Handshake (SYN -> SYN-ACK -> ACK via socket)              |
|   - TCP Port Multiplexing & Connection State Analysis                   |
+-------------------------------------------------------------------------+
                                    │
+-------------------------------------------------------------------------+
|                        INTERNET LAYER (Layer 2/3)                       |
|   - IPv4 / IPv6 Addressing & Subnet Masking                             |
|   - ICMP (Type 8 Echo Request / Type 0 Echo Reply / Type 11 TTL Expired)|
|   - Gateway Forwarding & Hop-by-Hop Routing Topology                    |
+-------------------------------------------------------------------------+
                                    │
+-------------------------------------------------------------------------+
|                     NETWORK ACCESS LAYER (Layer 1/2)                    |
|   - Physical Network Interface Card (NIC) Binding & MAC Address         |
|   - Ethernet & 802.11 Wi-Fi Adapter State Detection                     |
+-------------------------------------------------------------------------+
```

### 2.1 The TCP/IP Model Mapping
* **Network Access Layer:** The `network_info` module detects active interface state (Wi-Fi 802.11 vs. 802.3 Ethernet), physical MAC address strings, and DHCP leasing state.
* **Internet Layer:** The `ping_test` and `traceroute` modules utilize ICMP messages to assess link availability, round-trip latency, and intermediate router hops.
* **Transport Layer:** The `port_checker` module tests connection setup using Python’s standard `socket` library, directly observing socket error codes (`WSAECONNREFUSED` / `ETIMEDOUT`).
* **Application Layer:** DNS resolution translates FQDNs into 32-bit IPv4 or 128-bit IPv6 records, and the local Flask HTTP server binds to port 5000 to deliver the SPA dashboard.

### 2.2 ICMP & Round-Trip Latency Dynamics
ICMP (Internet Control Message Protocol, RFC 792) provides network-layer operational feedback:
$$\text{Latency (RTT)} = t_{\text{EchoReply\_Received}} - t_{\text{EchoRequest\_Transmitted}}$$
$$\text{Packet Loss \%} = \left(\frac{\text{Packets Sent} - \text{Packets Received}}{\text{Packets Sent}}\right) \times 100\%$$

### 2.3 Traceroute and TTL Decrementation
Traceroute operates by deliberately triggering ICMP Time Exceeded (Type 11, Code 0) messages. For each probe $n \in [1, \text{max\_hops}]$:
1. The packet is dispatched with $\text{TTL} = n$.
2. The $n$-th router decrements $\text{TTL} \to 0$, discards the datagram, and returns an ICMP Type 11 message containing the router's IP address.
3. This process continues iteratively until the target IP replies with an Echo Reply or the maximum hop threshold is reached.

### 2.4 TCP Three-Way Handshake & Port States
When testing port accessibility:
* **OPEN:** Target host responds with `[SYN, ACK]`; client sends `[ACK]`; handshake succeeds.
* **CLOSED:** Target host responds with `[RST, ACK]` (Reset), indicating reachability at Layer 3 but no listening socket at Layer 4 (`ConnectionRefusedError`).
* **FILTERED:** Target host or intermediate packet filter discards the `[SYN]`; client retransmits until timeout occurs (`socket.timeout`).

---

## 3. System Architecture & Module Design

The system implements a decoupled client-server architecture:

```
[ Browser: Single-Page Application (SPA) ]
                   │
                   ▼  HTTP REST API (JSON)
       [ Flask Application Router: app.py ]
         ├── GET  /api/network-info
         ├── POST /api/ping
         ├── POST /api/dns-lookup
         ├── POST /api/traceroute
         ├── POST /api/port-check
         ├── POST /api/quick-diagnose
         ├── POST /api/download-report
         └── POST /api/analyse
                   │
    ┌──────────────┴────────────────────────┐
    ▼                                       ▼
[ Low-Level Diagnostic Probes ]     [ Rule-Based Troubleshooting Engine ]
 ├── network_info.py                 ├── Deterministic Inference Rules
 ├── ping_test.py                    ├── Severity Assessment (Critical->Low)
 ├── dns_lookup.py                   ├── Health Score Computation (0-100)
 ├── traceroute.py                   └── Natural Language Explanations
 └── port_checker.py
```

### 3.1 Subprocess & Security Considerations
To prevent command injection vulnerabilities, **no arbitrary shell commands (`shell=True`) are executed**. All subprocess arguments are passed as isolated string arrays:
```python
# Safe invocation without shell expansion
cmd = ["ping", "-n", str(count), validated_target]
proc = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
```
Target hosts and port inputs are strictly sanitized using regular expressions (`^[a-zA-Z0-9.\-_]+$`) before processing.

---

## 4. Troubleshooting Engine: Rule Inference Matrix

The decision engine applies deterministic rule logic against collected metrics to calculate the network health score:

| Rule ID | Precondition / Diagnostic Evidence | Detected Issue | Severity | Score Impact |
|---|---|---|---|---|
| `R-01` | Local IP is `Unavailable` or null | No Active Network Interface | Critical | -40 |
| `R-02` | Gateway configured but ICMP ping failed | Default Gateway Unreachable | Critical | -40 |
| `R-03` | `getaddrinfo` throws `gaierror` | DNS Resolution Failure | High | -25 |
| `R-04` | Gateway ping OK, but ping to `8.8.8.8` failed | No Internet Connectivity (ISP Outage) | High | -25 |
| `R-05` | Ping packet loss percentage $> 50\%$ | Severe Packet Loss | High | -25 |
| `R-06` | Ping packet loss percentage between $10\%$ and $50\%$ | Moderate Packet Loss | Medium | -15 |
| `R-07` | Ping average round-trip time $> 500\text{ ms}$ | Very High Latency | High | -25 |
| `R-08` | Ping average round-trip time $> 200\text{ ms}$ | High Network Latency | Medium | -15 |
| `R-09` | TCP connection returned `ConnectionRefusedError` | Port Closed / Service Inactive | Medium | -15 |
| `R-10` | TCP connection timed out (`socket.timeout`) | Port Filtered / Firewall Block | Medium | -15 |
| `R-11` | Traceroute hops terminated before reaching target | Routing Issue / Path Block | Medium | -15 |
| `R-12` | All executed tests completed with 0 errors | Network Appears Healthy | Info | 0 |

$$\text{Health Score} = \max\left(0, 100 - \sum \text{Deductions}\right)$$

---

## 5. Experimental Test Cases & Validation Results

The project was validated using both unit tests (`test_suite.py`) and live network validation:

| Test ID | Test Category | Input Parameter | Expected Output | Actual Observed Result | Status |
|---|---|---|---|---|---|
| `TC-01` | Input Sanitization | `google.com; dir` | Reject target, error string | Target contains invalid characters | **PASS** |
| `TC-02` | Local IP Probing | System local adapter | Valid IPv4 format `x.x.x.x` | `172.20.10.2` discovered | **PASS** |
| `TC-03` | Loopback ICMP Ping | `127.0.0.1`, count=2 | 0% loss, $<1\text{ ms}$ RTT | 0.0% loss, 0.0 ms avg RTT | **PASS** |
| `TC-04` | Internet ICMP Ping | `google.com`, count=2 | 0% loss, valid RTT | 0.0% loss, 55.0 ms avg RTT | **PASS** |
| `TC-05` | DNS Query | `google.com` | Resolved A/AAAA records | `142.251.43.238` resolved in 7.49 ms | **PASS** |
| `TC-06` | Port Check (Open) | `google.com:443` | Connection established | HTTP 200, Open in 59.0 ms | **PASS** |
| `TC-07` | Port Check (Closed) | `127.0.0.1:44444` | Handshake refused | Connection refused at localhost:44444 | **PASS** |
| `TC-08` | Quick Auto-Diagnose | Complete pipeline | Full JSON report object | Executed ping + DNS + rules in 3.1s | **PASS** |
| `TC-09` | Report Generation | Format: TXT / JSON | Downloadable file headers | `Content-Disposition: attachment` | **PASS** |

---

## 6. Viva-Voce / Oral Examination Preparation Guide

This section is prepared specifically to assist students during project viva-voce examinations:

**Q1: How does your tool discover the local IP address without making an external HTTP request?**  
*Answer:* We create a UDP socket object via Python's `socket.socket(socket.AF_INET, socket.SOCK_DGRAM)` and invoke `.connect(('8.8.8.8', 80))`. Because UDP is connectionless, no packets are actually transmitted across the wire, but the operating system's routing table selects the appropriate network interface and populates `.getsockname()[0]` with the local IP address.

**Q2: What is the difference between a TCP port being "Closed" vs. "Filtered"?**  
*Answer:* A "Closed" port means the host received the initial TCP `[SYN]` packet and immediately responded with a TCP `[RST]` (Reset) packet. This proves Layer 3 connectivity exists, but no process is bound to the port. A "Filtered" port means the packet was silently dropped by a packet filter/firewall, resulting in a timeout on the client side with no packet returned.

**Q3: Why did you use a rule-based engine instead of a Machine Learning or Large Language Model?**  
*Answer:* Network troubleshooting follows well-defined RFC standards and deterministic logic. A rule-based engine guarantees 100% explainability, deterministic latency, requires zero GPU/cloud API costs, works completely offline, and does not suffer from hallucinations or non-reproducible outputs.

**Q4: How does Traceroute identify intermediate router hops?**  
*Answer:* It relies on the IP packet header's Time-To-Live (TTL) field. When an intermediate router receives a packet with $\text{TTL}=1$, it decrements the TTL to 0. Per RFC 792, the router must drop the packet and dispatch an ICMP Type 11 (Time Exceeded) message back to the source host, revealing its own interface IP in the source address field.

---

## 7. Conclusion

The **AI Network Troubleshooting Assistant** successfully delivers a reliable, fully local, and academically sound networking tool. By integrating low-level ICMP and TCP socket operations into an intuitive dashboard with a transparent rule-based analysis layer, it bridges the gap between raw networking telemetry and actionable diagnostic insights.

---
*End of Mini-Project Report.*
