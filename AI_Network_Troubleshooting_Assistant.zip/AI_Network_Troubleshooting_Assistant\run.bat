@echo off
TITLE AI Network Troubleshooting Assistant Launcher
color 0A

echo ======================================================================
echo          AI NETWORK TROUBLESHOOTING ASSISTANT
echo               Computer Networks Mini-Project
echo ======================================================================
echo.

:: Check for Python
where py >nul 2>nul
if %ERRORLEVEL% EQU 0 (
    set PYTHON_CMD=py -3
    goto :PYTHON_FOUND
)

where python >nul 2>nul
if %ERRORLEVEL% EQU 0 (
    set PYTHON_CMD=python
    goto :PYTHON_FOUND
)

where python3 >nul 2>nul
if %ERRORLEVEL% EQU 0 (
    set PYTHON_CMD=python3
    goto :PYTHON_FOUND
)

echo [ERROR] Python was not found on your system!
echo Please install Python 3.8+ from https://www.python.org/
echo Make sure to check "Add Python to PATH" during installation.
echo.
pause
exit /b 1

:PYTHON_FOUND
echo [*] Python detected:
%PYTHON_CMD% --version
echo.

:: Check / Create Virtual Environment (Optional, fallback to direct pip)
if not exist "venv" (
    echo [*] Setting up local virtual environment (venv)...
    %PYTHON_CMD% -m venv venv
)

if exist "venv\Scripts\activate.bat" (
    echo [*] Activating virtual environment...
    call venv\Scripts\activate.bat
    set RUN_CMD=python
) else (
    set RUN_CMD=%PYTHON_CMD%
)

echo [*] Checking and installing dependencies...
%RUN_CMD% -m pip install -r requirements.txt --quiet
if %ERRORLEVEL% NEQ 0 (
    echo [!] Warning: Pip install had warnings or errors. Attempting to continue...
)

echo.
echo ======================================================================
echo [*] Starting Flask Application...
echo [*] Web Dashboard URL: http://localhost:5000
echo [*] Press Ctrl+C in this window to stop the server
echo ======================================================================
echo.

:: Open default browser automatically after 2 seconds
start "" http://localhost:5000

%RUN_CMD% app.py

pause
