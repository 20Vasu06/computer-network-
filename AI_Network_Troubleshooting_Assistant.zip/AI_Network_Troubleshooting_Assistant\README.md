# AI Network Troubleshooting Assistant

> A locally running web-based application that diagnoses common network connectivity problems, analyses diagnostic results, identifies potential causes, and recommends solutions. Built as a Computer Networks mini-project using Python and Flask.

---

## 📋 Table of Contents

1. [Project Overview](#project-overview)
2. [Objectives](#objectives)
3. [Features](#features)
4. [Technologies Used](#technologies-used)
5. [Computer Networks Concepts Covered](#computer-networks-concepts-covered)
6. [Project Architecture](#project-architecture)
7. [Folder Structure](#folder-structure)
8. [Installation Instructions](#installation-instructions)
9. [How to Run the Application](#how-to-run-the-application)
10. [How to Use Each Feature](#how-to-use-each-feature)
11. [Screenshots](#screenshots)
12. [Limitations and Future Improvements](#limitations-and-future-improvements)
13. [GitHub Upload Instructions](#github-upload-instructions)

---

## 📌 Project Overview

The **AI Network Troubleshooting Assistant** is a full-stack web application that runs entirely on your local machine. It provides a professional network monitoring dashboard where you can:

- View your current network configuration (IP, gateway, DNS, etc.)
- Run ping tests to measure connectivity and latency
- Perform DNS lookups to resolve domain names
- Trace network routes hop-by-hop using traceroute
- Check TCP port connectivity for specific services
- Get intelligent, plain-English troubleshooting recommendations powered by a rule-based diagnostic engine

The application **does not require any internet API keys**, cloud services, or paid subscriptions. Everything runs offline on your computer. The diagnostic engine uses deterministic rule-based logic (not a machine learning model) to identify common network issues.

---

## 🎯 Objectives

- Provide a practical, hands-on tool for diagnosing common network problems
- Demonstrate implementation of core Computer Networks concepts (TCP/IP, ICMP, DNS, TCP, Routing)
- Build a fully functional client-server web application using Python/Flask
- Present results in a user-friendly, non-technical language
- Produce downloadable diagnostic reports for documentation

---

## ✅ Features

### A. Network Information
- Detects the active network interface
- Displays local IPv4 address, subnet mask, default gateway
- Shows hostname, DNS servers, MAC address, DHCP status
- Works via `ipconfig /all` parsing on Windows

### B. Ping Test
- Enter any IP address or domain name
- Configurable packet count (1–10)
- Displays min/avg/max latency, packet loss percentage
- Quick-target chips for common destinations
- Full raw output available for inspection

### C. DNS Lookup
- Resolves domain names to IPv4 and IPv6 addresses
- Measures resolution time in milliseconds
- Performs reverse DNS lookup on the first resolved IP
- Displays your configured DNS servers

### D. Traceroute
- Traces the hop-by-hop path to any destination
- Displays each hop's IP address and 3 RTT measurements
- Colour-coded latency (green/yellow/red)
- Handles timeout hops (`* * *`) gracefully
- Full raw output available

### E. Port Connectivity Checker
- Tests TCP connectivity to any host:port combination
- Configurable timeout
- Quick-select grid for 12 common services (HTTP, HTTPS, SSH, FTP, DNS, RDP, etc.)
- Distinguishes between closed (refused) and filtered (firewall) ports

### F. AI Troubleshooting Assistant (Rule-Based Engine)
- One-click auto-diagnosis (runs all tests automatically)
- Identifies: gateway unreachable, DNS failure, no internet, packet loss, high latency, port issues, routing problems
- Each issue shows: severity level, diagnostic evidence, possible cause, step-by-step solution
- Overall health score (0–100) with Good/Fair/Poor/Critical rating

### G. Diagnostic Report
- Summary table of all completed tests
- TXT and JSON report download
- Real-time report preview in the browser

---

## 🛠 Technologies Used

| Technology | Purpose |
|---|---|
| **Python 3.x** | Primary programming language |
| **Flask 3.x** | Web framework (backend server + API) |
| **HTML5** | Page structure and templates (Jinja2) |
| **CSS3** | Styling — dark theme dashboard design |
| **JavaScript (ES6+)** | Frontend interactions, API calls, dynamic rendering |
| **socket** (stdlib) | DNS resolution, TCP port testing |
| **subprocess** (stdlib) | Running ping, traceroute, ipconfig commands |
| **re** (stdlib) | Parsing command output with regex |
| **platform** (stdlib) | OS detection (Windows vs Linux/macOS) |
| **datetime, time** (stdlib) | Timestamps and latency measurement |

**No paid APIs. No cloud services. No external databases. Fully offline.**

---

## 🧠 Computer Networks Concepts Covered

### 1. TCP/IP Model
The application demonstrates all 4 layers of the TCP/IP model in practice:
- **Application Layer**: The web interface communicates over HTTP (Flask)
- **Transport Layer**: TCP port testing verifies transport-layer connectivity; ping operates over the network layer
- **Internet Layer**: ICMP (ping/traceroute), IPv4 addressing, routing
- **Network Access Layer**: Physical interface detection (MAC address, adapter type)

### 2. IPv4 Addressing
- Displays the device's private IPv4 address (e.g. `192.168.1.x`)
- Shows subnet mask and calculates the network prefix
- Distinguishes between APIPA addresses (169.254.x.x — no DHCP) and valid addresses

### 3. ICMP Protocol
- **Ping** uses ICMP Echo Request/Reply messages to test reachability
- **Traceroute** exploits ICMP Time Exceeded messages sent by routers when TTL expires
- Packet loss and round-trip time (RTT) are core ICMP metrics

### 4. DNS (Domain Name System)
- Resolves human-readable hostnames to IP addresses
- Measures resolution latency (should typically be <50ms)
- Supports both A (IPv4) and AAAA (IPv6) records
- Performs reverse DNS (PTR record lookups)

### 5. TCP Connections
- Port checker uses `socket.create_connection()` to perform a full TCP 3-way handshake
- Measures round-trip time for establishing a TCP connection
- Differentiates between refused (RST) and filtered (timeout) connections

### 6. Port Numbers
- Well-known ports: HTTP(80), HTTPS(443), SSH(22), FTP(21), DNS(53), SMTP(25), RDP(3389)
- Port 1–65535 (16-bit address space)
- Application layer services are identified by port number

### 7. Routing and Traceroute
- Default gateway: the router all external traffic passes through
- Traceroute reveals intermediate routers (hops) along the path
- TTL (Time-To-Live): each router decrements TTL by 1; TTL=0 triggers ICMP Time Exceeded

### 8. Latency and Packet Loss
- Latency (RTT) = time for a packet to travel to the destination and back
- Packet loss = percentage of sent packets that never return
- Used by the troubleshooting engine to classify connection quality

### 9. Client-Server Architecture
- Flask provides the server-side REST API
- JavaScript frontend acts as the client, making `fetch()` calls to the backend
- Results are exchanged as JSON over HTTP

---

## 🏗 Project Architecture

```
Browser (Client)
      │  HTTP/JSON
      ▼
Flask Web Server (app.py)
      │
      ├── /api/network-info     → diagnostics/network_info.py
      ├── /api/ping             → diagnostics/ping_test.py
      ├── /api/dns-lookup       → diagnostics/dns_lookup.py
      ├── /api/traceroute       → diagnostics/traceroute.py
      ├── /api/port-check       → diagnostics/port_checker.py
      ├── /api/analyse          → diagnostics/troubleshooter.py
      ├── /api/quick-diagnose   → (runs all of the above)
      └── /api/download-report  → (generates TXT/JSON file)

Troubleshooting Engine (rule-based, deterministic):
  Input:  dict of diagnostic results
  Output: issues[], health_score, overall_health, summary, recommendations
```

**Security model:**
- All subprocess calls use argument lists (never `shell=True`)
- User inputs are validated with regex before being passed anywhere
- Shell metacharacters are explicitly rejected
- Timeouts are enforced on all external commands
- No user data is stored or transmitted anywhere

---

## 📁 Folder Structure

```
AI_Network_Troubleshooting_Assistant/
│
├── app.py                      # Flask application — routes and REST API endpoints
├── run.bat                     # Windows one-click launcher (creates venv, installs, runs)
├── run.sh                      # Linux/macOS one-click launcher
├── test_suite.py               # Comprehensive unit & integration automated test suite
├── PROJECT_REPORT.md           # Complete academic mini-project report (Viva Q&A included)
│
├── diagnostics/                # Network diagnostic modules
│   ├── __init__.py             # Package marker
│   ├── network_info.py         # Network interface detection (ipconfig parser)
│   ├── ping_test.py            # Ping execution and result parser
│   ├── dns_lookup.py           # DNS resolution via socket
│   ├── traceroute.py           # Traceroute execution and hop parser
│   ├── port_checker.py         # TCP port connectivity testing
│   └── troubleshooter.py       # Rule-based troubleshooting engine
│
├── templates/
│   └── index.html              # Main Jinja2 HTML template (SPA dashboard)
│
├── static/
│   ├── css/
│   │   └── style.css           # Dark-theme dashboard styling
│   └── js/
│       └── app.js              # Frontend JavaScript (navigation, API calls, rendering)
│
├── requirements.txt            # Python dependencies (Flask only)
├── .gitignore                  # Files to exclude from Git
├── LICENSE                     # MIT License
└── README.md                   # Complete documentation
```

---

## 💻 Installation Instructions

> These instructions are written for **Windows 10/11**. Follow each step carefully.

### Step 1: Check that Python is installed

Open **Command Prompt** or **PowerShell**:

```
py --version
```

You should see something like `Python 3.11.x`. If you see an error, download Python from https://www.python.org/downloads/ and install it. During installation, **check the box that says "Add Python to PATH"**.

### Step 2: Download and extract the project

If you received a ZIP file:
1. Right-click `AI_Network_Troubleshooting_Assistant.zip`
2. Select **Extract All...**
3. Choose a folder (e.g. your Desktop or Documents)
4. Click **Extract**

### Step 3: Open the project folder in PowerShell

1. Open the extracted folder
2. Hold `Shift` and right-click inside the folder
3. Select **Open PowerShell window here** (or "Open in Terminal")

### Step 4: (Recommended) Create a virtual environment

A virtual environment keeps this project's dependencies separate from other Python projects:

```powershell
py -m venv venv
venv\Scripts\activate
```

After running these commands, you should see `(venv)` at the start of your terminal prompt.

### Step 5: Install dependencies

```powershell
pip install -r requirements.txt
```

This installs Flask (the only required package). It should complete in under a minute.

---

## ▶ How to Run the Application

### Starting the server

Inside the project folder (with virtual environment active if you created one):

```powershell
py app.py
```

You will see output like:
```
==================================================
  AI Network Troubleshooting Assistant
  Starting Flask server...
  Open http://localhost:5000 in your browser
  Press Ctrl+C to stop the server
==================================================
 * Running on http://127.0.0.1:5000
```

### Opening the application

Open your web browser (Chrome, Edge, or Firefox) and go to:

```
http://localhost:5000
```

The dashboard will load immediately.

### Stopping the server

Press **Ctrl + C** in the PowerShell window where the server is running.

---

## 📖 How to Use Each Feature

### Dashboard
The main page shows your current network status, IP address, gateway, and latency at a glance.

- **Quick Diagnose button** — automatically runs ping + DNS tests and analyses the results
- **Quick Actions** — navigate to any diagnostic tool directly
- **Recent Results** — shows the last 20 diagnostic operations

### Network Information
1. Click **Network Info** in the sidebar
2. The page automatically loads your network configuration
3. Click **↻ Refresh** to get updated information

### Ping Test
1. Click **Ping Test** in the sidebar
2. Type an IP address or domain name in the input field (e.g. `google.com` or `8.8.8.8`)
3. Set the packet count (1–10, default 4)
4. Click **▶ Run Ping**
5. — OR — click one of the **Quick targets** chips to auto-fill and run

Results show minimum, average, and maximum latency, packet loss percentage, and the raw ping output.

### DNS Lookup
1. Click **DNS Lookup** in the sidebar
2. Enter a domain name (e.g. `github.com`)
3. Click **🔍 Lookup**

Results show all resolved IP addresses, resolution time, and the reverse DNS hostname.

### Traceroute
1. Click **Traceroute** in the sidebar
2. Enter a destination (e.g. `google.com`)
3. Click **🗺️ Trace Route**
4. ⏱️ Wait — traceroute can take up to 2 minutes

The hop table shows each router along the path with 3 latency measurements. Rows with `* * *` are routers that don't respond to traceroute (this is normal for many routers).

### Port Checker
1. Click **Port Checker** in the sidebar
2. Enter a hostname (e.g. `google.com`)
3. Enter a port number (e.g. `443`) or click one of the **Common Ports** buttons to auto-fill
4. Click **🔌 Check Port**

Results tell you if the port is **Open** (service running), **Closed** (service not running), or **Filtered** (blocked by firewall).

### AI Assistant
1. Click **AI Assistant** in the sidebar
2. Click **⚡ Quick Auto-Diagnose** to automatically run all tests
3. Wait for the analysis (usually 10–30 seconds)

The assistant shows:
- **Health Score** (0–100) with colour coding
- **Issue cards** — each with severity level, evidence, cause, and step-by-step solution
- **Top Recommendations** for quick action

### Reports
1. Click **Reports** in the sidebar
2. The summary table shows all tests you have run this session
3. Click **⬇ Download TXT** for a readable plain-text report
4. Click **⬇ Download JSON** for a machine-readable report

---

## 📸 Screenshots

> To add screenshots to this README for your submission:
>
> 1. Run the application and open it in your browser
> 2. Press `F12` to open Developer Tools (optional, for inspecting the UI)
> 3. Take screenshots of:
>    - The Dashboard with network info loaded
>    - The Ping Test results
>    - The AI Assistant analysis results
>    - The Traceroute hop table
>    - The Port Checker results
> 4. Save the screenshots in a `screenshots/` folder inside the project
> 5. Add them to this README using the syntax below:

```markdown
## Screenshots

### Dashboard
![Dashboard](screenshots/dashboard.png)

### Ping Test Results
![Ping Test](screenshots/ping_test.png)

### AI Assistant Analysis
![AI Assistant](screenshots/ai_assistant.png)

### Traceroute Hops
![Traceroute](screenshots/traceroute.png)
```

---

## ⚠ Limitations and Future Improvements

### Current Limitations

| Limitation | Explanation |
|---|---|
| **Gateway detection on some networks** | On certain network configurations (mobile hotspots, VPNs), the default gateway may show as "Unavailable". The local IP is still detected correctly via socket. |
| **Traceroute on firewalled networks** | Corporate networks and some ISPs block ICMP, causing all hops to show `* * *`. The traceroute still runs but yields less information. |
| **Windows only for full feature set** | The application is primarily designed for Windows. Linux/macOS support exists but `traceroute` command availability may vary. |
| **No persistent data storage** | Diagnostic results are stored in browser memory only and lost on page refresh. Reports must be downloaded before closing. |
| **Single-user local server** | The Flask development server is not intended for production or multi-user deployment. |
| **ICMP may require privilege on Linux** | On Linux, raw ICMP socket ping may require root. The application uses the system `ping` command to avoid this. |

### Planned Future Improvements

- **Continuous monitoring mode** — automatically run ping every N seconds and plot latency over time
- **Historical data persistence** — save results to a local SQLite database
- **Network map visualization** — visual graph of traceroute hops
- **Export to PDF** — formatted diagnostic report as PDF
- **WiFi signal strength** — detect and display wireless signal strength (RSSI)
- **Speed test integration** — measure upload/download bandwidth
- **Multiple target ping** — ping several hosts simultaneously
- **Scheduled diagnostics** — run health checks on a timer

---

## 🐙 GitHub Upload Instructions

Follow these steps to upload the project to GitHub and get a repository link.

### Step 1: Create a GitHub account
If you don't have one, sign up at https://github.com/

### Step 2: Create a new repository
1. Click the **+** button in the top-right corner of GitHub
2. Select **New repository**
3. Name it: `AI-Network-Troubleshooting-Assistant`
4. Set it to **Public** (so your professor can view it)
5. **Do NOT** check "Add a README file" (you already have one)
6. Click **Create repository**

### Step 3: Upload your files
GitHub will show you instructions. Use the **"uploading an existing file"** option:
1. Click **uploading an existing file**
2. Drag and drop ALL the project files and folders onto the upload area
   - `app.py`
   - `requirements.txt`
   - `README.md`
   - `.gitignore`
   - `LICENSE`
   - The `diagnostics/` folder and all its files
   - The `templates/` folder
   - The `static/` folder and all its contents
3. Add a commit message: `Initial commit — AI Network Troubleshooting Assistant`
4. Click **Commit changes**

### Step 4: Verify the repository
Your repository URL will be:
```
https://github.com/YOUR_USERNAME/AI-Network-Troubleshooting-Assistant
```

Share this URL for your project submission.

### Alternative: Upload using Git command line

If you have Git installed (`git --version` to check):

```powershell
# Inside the project folder:
git init
git add .
git commit -m "Initial commit — AI Network Troubleshooting Assistant"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/AI-Network-Troubleshooting-Assistant.git
git push -u origin main
```

---

## 📄 License

This project is licensed under the MIT License — see the [LICENSE](LICENSE) file for details.

---

*Built as a Computer Networks mini-project. All diagnostics run locally. No data is sent to external servers.*
