"""
network_info.py - Collects local network interface information.
Works on Windows using ipconfig /all output parsing.
"""

import socket
import subprocess
import platform
import re
from datetime import datetime


def parse_ipconfig(output: str) -> dict:
    """Parse ipconfig /all output and extract network interface details."""
    result = {
        "local_ip": "Unavailable",
        "subnet_mask": "Unavailable",
        "gateway": "Unavailable",
        "interface_name": "Unavailable",
        "dns_servers": [],
        "mac_address": "Unavailable",
        "dhcp_enabled": "Unknown",
    }

    # Split into adapter sections
    # Each adapter starts with a line like "Ethernet adapter Ethernet:" or "Wireless LAN adapter Wi-Fi:"
    adapter_pattern = re.compile(
        r"((?:Ethernet adapter|Wireless LAN adapter|Wi-Fi adapter)[^\n]+)\n((?:[ \t][^\n]*\n?)*)",
        re.MULTILINE,
    )

    best_adapter = None
    best_has_gateway = False

    for match in adapter_pattern.finditer(output):
        adapter_name = match.group(1).strip().rstrip(":")
        adapter_body = match.group(2)

        # Skip disconnected adapters
        if "Media disconnected" in adapter_body or "Media State" in adapter_body and "disconnected" in adapter_body:
            continue

        # Extract IPv4 address
        ip_match = re.search(
            r"IPv4 Address[.\s]+:\s*([\d.]+)", adapter_body
        )
        if not ip_match:
            ip_match = re.search(r"IP Address[.\s]+:\s*([\d.]+)", adapter_body)
        if not ip_match:
            continue

        ip_addr = ip_match.group(1).strip()
        if ip_addr.startswith("169.254"):  # APIPA address - skip
            continue

        # Extract subnet mask
        mask_match = re.search(r"Subnet Mask[.\s]+:\s*([\d.]+)", adapter_body)
        subnet = mask_match.group(1).strip() if mask_match else "Unavailable"

        # Extract default gateway
        gw_match = re.search(
            r"Default Gateway[.\s]+:\s*([\d.a-fA-F:]+)", adapter_body
        )
        gateway = gw_match.group(1).strip() if gw_match else ""

        # Extract DNS servers
        dns_match = re.findall(
            r"DNS Servers[.\s]+:\s*([\d.]+)", adapter_body
        )

        # Extract MAC address
        mac_match = re.search(
            r"Physical Address[.\s]+:\s*([0-9A-Fa-f-]+)", adapter_body
        )
        mac = mac_match.group(1).strip() if mac_match else "Unavailable"

        # DHCP
        dhcp_match = re.search(r"DHCP Enabled[.\s]+:\s*(\w+)", adapter_body)
        dhcp = dhcp_match.group(1).strip() if dhcp_match else "Unknown"

        has_gateway = bool(gateway and gateway not in ("", "Unavailable"))

        # Prefer adapter with a gateway
        if best_adapter is None or (has_gateway and not best_has_gateway):
            best_adapter = {
                "local_ip": ip_addr,
                "subnet_mask": subnet,
                "gateway": gateway if gateway else "Unavailable",
                "interface_name": adapter_name,
                "dns_servers": dns_match,
                "mac_address": mac,
                "dhcp_enabled": dhcp,
            }
            best_has_gateway = has_gateway

    if best_adapter:
        result.update(best_adapter)

    return result


def get_network_info() -> dict:
    """
    Collect comprehensive network information.
    Returns a dict with all available network details.
    Never crashes — missing data is marked as 'Unavailable'.
    """
    info = {
        "hostname": "Unavailable",
        "local_ip": "Unavailable",
        "subnet_mask": "Unavailable",
        "gateway": "Unavailable",
        "interface_name": "Unavailable",
        "dns_servers": [],
        "connection_type": "Unavailable",
        "mac_address": "Unavailable",
        "dhcp_enabled": "Unknown",
        "os": platform.system(),
        "timestamp": datetime.now().isoformat(),
        "error": None,
    }

    # Get hostname
    try:
        info["hostname"] = socket.gethostname()
    except Exception as e:
        info["hostname"] = "Unavailable"

    # Get local IP via socket connection (doesn't actually send data)
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
            s.settimeout(2)
            s.connect(("8.8.8.8", 80))
            info["local_ip"] = s.getsockname()[0]
    except Exception:
        pass

    # Use ipconfig /all for detailed info on Windows
    if platform.system() == "Windows":
        try:
            proc = subprocess.run(
                ["ipconfig", "/all"],
                capture_output=True,
                text=True,
                timeout=10,
                encoding="utf-8",
                errors="replace",
            )
            if proc.returncode == 0 and proc.stdout:
                parsed = parse_ipconfig(proc.stdout)
                # Merge parsed info, keeping socket-based IP if available
                if info["local_ip"] == "Unavailable" and parsed["local_ip"] != "Unavailable":
                    info["local_ip"] = parsed["local_ip"]
                info["subnet_mask"] = parsed["subnet_mask"]
                info["gateway"] = parsed["gateway"]
                info["interface_name"] = parsed["interface_name"]
                info["dns_servers"] = parsed["dns_servers"]
                info["mac_address"] = parsed["mac_address"]
                info["dhcp_enabled"] = parsed["dhcp_enabled"]
        except subprocess.TimeoutExpired:
            info["error"] = "ipconfig timed out"
        except FileNotFoundError:
            info["error"] = "ipconfig not found"
        except Exception as e:
            info["error"] = f"Could not run ipconfig: {str(e)}"
    else:
        # Linux/macOS fallback
        try:
            import subprocess as sp
            proc = sp.run(
                ["ip", "route", "show", "default"],
                capture_output=True, text=True, timeout=5
            )
            gw_match = re.search(r"default via ([\d.]+)", proc.stdout)
            if gw_match:
                info["gateway"] = gw_match.group(1)
        except Exception:
            pass

    # Determine connection type from interface name
    iface = info.get("interface_name", "").lower()
    if any(w in iface for w in ["wi-fi", "wireless", "wlan", "wifi"]):
        info["connection_type"] = "Wi-Fi (Wireless)"
    elif any(w in iface for w in ["ethernet", "eth", "lan"]):
        info["connection_type"] = "Ethernet (Wired)"
    elif any(w in iface for w in ["loopback", "lo"]):
        info["connection_type"] = "Loopback"
    elif info["local_ip"] != "Unavailable":
        info["connection_type"] = "Network Connected"
    else:
        info["connection_type"] = "No Active Connection"

    return info


def get_connection_summary(info: dict = None) -> str:
    """Return a one-line human-readable summary of the network connection."""
    if info is None:
        info = get_network_info()

    if info.get("local_ip") == "Unavailable":
        return "No active network connection detected."

    parts = [f"Connected via {info.get('connection_type', 'Network')}"]
    if info.get("local_ip") != "Unavailable":
        parts.append(f"IP: {info['local_ip']}")
    if info.get("gateway") != "Unavailable":
        parts.append(f"Gateway: {info['gateway']}")

    return " | ".join(parts)


if __name__ == "__main__":
    import json
    data = get_network_info()
    print(json.dumps(data, indent=2))
    print(get_connection_summary(data))
