"""
ping_test.py - Execute ping tests and parse results.
Works on Windows using 'ping' command. No admin privileges required.
"""

import subprocess
import re
import platform
from datetime import datetime


# Characters that must not appear in a user-supplied target
_DANGEROUS_CHARS = set(';&|`$(){}[]<>\'"\\')


def validate_target(target: str) -> tuple:
    """
    Validate a user-supplied ping target (IP or hostname).

    Returns:
        (True, "") if valid
        (False, error_message) if invalid
    """
    if not target:
        return False, "Target cannot be empty."

    target = target.strip()

    if len(target) > 253:
        return False, "Target is too long (max 253 characters)."

    if any(c in _DANGEROUS_CHARS for c in target):
        return False, "Target contains invalid characters."

    # Allow: letters, digits, dots, hyphens, underscores (valid for IPs and hostnames)
    if not re.match(r'^[a-zA-Z0-9.\-_]+$', target):
        return False, "Target contains unsupported characters."

    return True, ""


def _parse_windows_ping(output: str, target: str) -> dict:
    """Parse Windows ping command output."""
    result = {
        "packets_sent": 0,
        "packets_received": 0,
        "packets_lost": 0,
        "packet_loss_pct": 0.0,
        "min_latency_ms": None,
        "max_latency_ms": None,
        "avg_latency_ms": None,
    }

    # Packets: Sent = X, Received = Y, Lost = Z (N% loss)
    pkt_match = re.search(
        r"Sent\s*=\s*(\d+),\s*Received\s*=\s*(\d+),\s*Lost\s*=\s*(\d+)\s*\((\d+)%\s*loss\)",
        output, re.IGNORECASE
    )
    if pkt_match:
        result["packets_sent"] = int(pkt_match.group(1))
        result["packets_received"] = int(pkt_match.group(2))
        result["packets_lost"] = int(pkt_match.group(3))
        result["packet_loss_pct"] = float(pkt_match.group(4))

    # Minimum = Xms, Maximum = Yms, Average = Zms
    latency_match = re.search(
        r"Minimum\s*=\s*(\d+)ms,\s*Maximum\s*=\s*(\d+)ms,\s*Average\s*=\s*(\d+)ms",
        output, re.IGNORECASE
    )
    if latency_match:
        result["min_latency_ms"] = float(latency_match.group(1))
        result["max_latency_ms"] = float(latency_match.group(2))
        result["avg_latency_ms"] = float(latency_match.group(3))

    return result


def _parse_unix_ping(output: str, target: str) -> dict:
    """Parse Unix/Linux/macOS ping output."""
    result = {
        "packets_sent": 0,
        "packets_received": 0,
        "packets_lost": 0,
        "packet_loss_pct": 0.0,
        "min_latency_ms": None,
        "max_latency_ms": None,
        "avg_latency_ms": None,
    }

    # X packets transmitted, Y received, Z% packet loss
    pkt_match = re.search(
        r"(\d+)\s+packets?\s+transmitted,\s*(\d+)\s+(?:packets?\s+)?received,\s*(\d+(?:\.\d+)?)%\s+packet loss",
        output, re.IGNORECASE
    )
    if pkt_match:
        result["packets_sent"] = int(pkt_match.group(1))
        result["packets_received"] = int(pkt_match.group(2))
        result["packets_lost"] = result["packets_sent"] - result["packets_received"]
        result["packet_loss_pct"] = float(pkt_match.group(3))

    # rtt min/avg/max/mdev = X/Y/Z/W ms
    latency_match = re.search(
        r"rtt\s+min/avg/max/\w+\s*=\s*([\d.]+)/([\d.]+)/([\d.]+)",
        output
    )
    if latency_match:
        result["min_latency_ms"] = float(latency_match.group(1))
        result["avg_latency_ms"] = float(latency_match.group(2))
        result["max_latency_ms"] = float(latency_match.group(3))

    return result


def run_ping(target: str, count: int = 4) -> dict:
    """
    Run a ping test to the specified target.

    Args:
        target: IP address or hostname to ping
        count: Number of ping packets (1-20)

    Returns:
        dict with ping results. Never crashes.
    """
    timestamp = datetime.now().isoformat()

    # Validate inputs
    is_valid, error_msg = validate_target(target)
    if not is_valid:
        return {
            "success": False,
            "target": target,
            "error": error_msg,
            "avg_latency_ms": None,
            "min_latency_ms": None,
            "max_latency_ms": None,
            "packets_sent": 0,
            "packets_received": 0,
            "packets_lost": 0,
            "packet_loss_pct": 0.0,
            "raw_output": "",
            "timestamp": timestamp,
        }

    # Clamp count
    count = max(1, min(count, 20))
    target = target.strip()

    # Build command (list form — no shell injection possible)
    is_windows = platform.system() == "Windows"
    if is_windows:
        cmd = ["ping", "-n", str(count), target]
    else:
        cmd = ["ping", "-c", str(count), target]

    result = {
        "success": False,
        "target": target,
        "avg_latency_ms": None,
        "min_latency_ms": None,
        "max_latency_ms": None,
        "packets_sent": count,
        "packets_received": 0,
        "packets_lost": count,
        "packet_loss_pct": 100.0,
        "raw_output": "",
        "error": None,
        "timestamp": timestamp,
    }

    try:
        proc = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=30,
            encoding="utf-8",
            errors="replace",
        )
        output = proc.stdout + proc.stderr
        result["raw_output"] = output.strip()

        # Parse results
        if is_windows:
            parsed = _parse_windows_ping(output, target)
        else:
            parsed = _parse_unix_ping(output, target)

        result.update(parsed)

        # Determine success
        # On Windows, return code 0 means at least one packet received
        # Also check packet statistics
        if proc.returncode == 0 and parsed["packets_received"] > 0:
            result["success"] = True
            result["error"] = None
        elif "could not find host" in output.lower() or "unknown host" in output.lower():
            result["error"] = f"Could not resolve hostname: {target}"
        elif "request timed out" in output.lower() or "100% loss" in output.lower():
            result["error"] = f"All packets lost — host may be unreachable or blocking ICMP"
        elif "destination host unreachable" in output.lower():
            result["error"] = f"Destination host unreachable: {target}"
        else:
            result["error"] = f"Ping failed (exit code {proc.returncode})"

    except subprocess.TimeoutExpired:
        result["error"] = "Ping command timed out after 30 seconds"
        result["raw_output"] = ""
    except FileNotFoundError:
        result["error"] = "ping command not found on this system"
    except Exception as e:
        result["error"] = f"Unexpected error: {str(e)}"

    return result


if __name__ == "__main__":
    import json
    print("Testing ping to google.com ...")
    r = run_ping("google.com", count=2)
    print(json.dumps(r, indent=2))
