"""
troubleshooter.py - Rule-based network troubleshooting engine.

This is NOT a machine learning model or an LLM.
It applies deterministic rule-based logic to analyse diagnostic results
and produce structured recommendations in plain English.
"""

from datetime import datetime


class TroubleshootingEngine:
    """
    Rule-based engine that analyses network diagnostic results
    and identifies potential issues with explanations and solutions.
    """

    # Severity weights for health score calculation
    _SEVERITY_DEDUCTIONS = {
        "critical": 40,
        "high": 25,
        "medium": 15,
        "low": 5,
        "info": 0,
    }

    def analyse(self, diagnostic_results: dict) -> dict:
        """
        Analyse diagnostic results and produce a structured troubleshooting report.

        Args:
            diagnostic_results: dict with optional keys:
                - ping_result: result from run_ping()
                - dns_result: result from run_dns_lookup()
                - traceroute_result: result from run_traceroute()
                - port_result: result from check_port()
                - network_info: result from get_network_info()
                - ping_gateway_result: ping result for gateway
                - ping_internet_result: ping result for internet (e.g. 8.8.8.8)

        Returns:
            dict with full analysis.
        """
        ping = diagnostic_results.get("ping_result") or {}
        dns = diagnostic_results.get("dns_result") or {}
        traceroute = diagnostic_results.get("traceroute_result") or {}
        port = diagnostic_results.get("port_result") or {}
        net_info = diagnostic_results.get("network_info") or {}
        ping_gw = diagnostic_results.get("ping_gateway_result") or {}
        ping_inet = diagnostic_results.get("ping_internet_result") or {}

        # Merge ping_result into appropriate slot if not separately provided
        if ping and not ping_gw and not ping_inet:
            target = ping.get("target", "")
            if target in ("8.8.8.8", "1.1.1.1", "8.8.4.4"):
                ping_inet = ping
            else:
                ping_gw = ping

        issues = []

        # ── Rule 1: No network interface ─────────────────────────────────────
        if net_info and net_info.get("local_ip") in ("Unavailable", None, ""):
            issues.append({
                "id": "no_interface",
                "title": "No Active Network Interface Found",
                "severity": "critical",
                "evidence": "Network scan returned no active interface with a valid IP address.",
                "possible_cause": (
                    "Your computer does not appear to be connected to any network. "
                    "This could mean: your Wi-Fi is turned off, the Ethernet cable is not plugged in, "
                    "your network adapter is disabled, or no network adapter is installed."
                ),
                "recommended_solution": [
                    "1. Check that your Wi-Fi is turned on (look for the Wi-Fi icon in the taskbar).",
                    "2. If using a wired connection, make sure the Ethernet cable is securely plugged in at both ends.",
                    "3. Open Device Manager (press Win+X → Device Manager) and check for any network adapter errors.",
                    "4. Right-click the network adapter and select 'Enable' if it is disabled.",
                    "5. Restart your computer and check again.",
                ],
                "affected_component": "Network Interface",
            })

        # ── Rule 2: Gateway unreachable ───────────────────────────────────────
        if ping_gw and not ping_gw.get("success") and net_info.get("gateway", "Unavailable") not in ("Unavailable", ""):
            gateway = net_info.get("gateway", "your gateway")
            issues.append({
                "id": "gateway_unreachable",
                "title": "Default Gateway Unreachable",
                "severity": "critical",
                "evidence": (
                    f"Ping to default gateway ({gateway}) failed. "
                    f"Error: {ping_gw.get('error', 'No response')}"
                ),
                "possible_cause": (
                    "Your router or gateway is not responding. "
                    "This usually means: your router is off or restarting, "
                    "there is a problem with your local network cable or Wi-Fi signal, "
                    "or your router's firewall is blocking ICMP ping packets."
                ),
                "recommended_solution": [
                    f"1. Try to open your browser and visit http://{gateway} to access the router admin page.",
                    "2. Check that your router is powered on (look for the power LED).",
                    "3. If using Wi-Fi, move closer to the router and check the signal strength.",
                    "4. If using Ethernet, try a different cable or port on the router.",
                    "5. Restart your router (unplug it, wait 30 seconds, plug it back in).",
                    "6. Some routers block ping — if the router page loads in step 1, the gateway is actually working.",
                ],
                "affected_component": "Gateway / Router",
            })

        # ── Rule 3: DNS resolution failure ────────────────────────────────────
        if dns and not dns.get("success"):
            issues.append({
                "id": "dns_failure",
                "title": "DNS Resolution Failure",
                "severity": "high",
                "evidence": (
                    f"DNS lookup for '{dns.get('domain', 'domain')}' failed. "
                    f"Error: {dns.get('error', 'Unknown error')}"
                ),
                "possible_cause": (
                    "Your computer cannot translate domain names (like google.com) into IP addresses. "
                    "This can happen when: your DNS server is down, "
                    "your DNS settings are incorrect, "
                    "you have no internet connection (and thus cannot reach the DNS server), "
                    "or the domain name itself does not exist."
                ),
                "recommended_solution": [
                    "1. Try visiting a website by its IP address instead of domain name to check if internet works.",
                    "2. Change your DNS server to a public one: open Network Settings → adapter properties → IPv4 → set DNS to 8.8.8.8 and 8.8.4.4 (Google DNS).",
                    "3. Flush your DNS cache: open Command Prompt and type: ipconfig /flushdns",
                    "4. Restart your router and wait 60 seconds before trying again.",
                    "5. Check if the domain name you entered is spelled correctly.",
                ],
                "affected_component": "DNS",
            })

        # ── Rule 4: No internet but gateway OK ────────────────────────────────
        if (ping_inet and not ping_inet.get("success") and
                (not ping_gw or ping_gw.get("success"))):
            issues.append({
                "id": "no_internet",
                "title": "No Internet Connectivity",
                "severity": "high",
                "evidence": (
                    f"Cannot reach internet host ({ping_inet.get('target', '8.8.8.8')}). "
                    f"Error: {ping_inet.get('error', 'No response')}. "
                    + ("Local gateway appears reachable." if ping_gw.get("success") else "")
                ),
                "possible_cause": (
                    "Your local network connection appears to be working (you can reach your router), "
                    "but traffic is not reaching the internet. "
                    "This could be caused by: your Internet Service Provider (ISP) having an outage, "
                    "your router not being authenticated with the ISP (PPPoE/DHCP issue), "
                    "or firewall rules blocking outbound traffic."
                ),
                "recommended_solution": [
                    "1. Check if other devices (phone, tablet) can access the internet — if not, the problem is with your ISP or router.",
                    "2. Restart your router/modem (unplug for 30 seconds then plug back in).",
                    "3. Log into your router admin page and check the WAN connection status.",
                    "4. Contact your Internet Service Provider (ISP) to report an outage.",
                    "5. Check if your ISP requires PPPoE credentials and that they are correctly entered in your router.",
                ],
                "affected_component": "Internet / ISP",
            })

        # ── Rule 5: Severe packet loss (>50%) ─────────────────────────────────
        ping_to_check = ping_inet if ping_inet else ping_gw if ping_gw else ping
        pkt_loss = ping_to_check.get("packet_loss_pct", 0)

        if pkt_loss > 50:
            issues.append({
                "id": "severe_packet_loss",
                "title": "Severe Packet Loss",
                "severity": "high",
                "evidence": (
                    f"{pkt_loss:.0f}% of packets were lost when pinging "
                    f"{ping_to_check.get('target', 'the target')}. "
                    f"({ping_to_check.get('packets_received', 0)}/{ping_to_check.get('packets_sent', 0)} packets received)"
                ),
                "possible_cause": (
                    "More than half of your network packets are being dropped. "
                    "Common causes: poor Wi-Fi signal, damaged network cable, "
                    "network congestion, failing network hardware, or ISP problems."
                ),
                "recommended_solution": [
                    "1. If on Wi-Fi: move closer to the router or use a 5GHz band instead of 2.4GHz.",
                    "2. If on Ethernet: try a different cable — cables can fail internally without visible damage.",
                    "3. Restart your router and modem.",
                    "4. Check if other devices experience the same packet loss.",
                    "5. If the problem persists, contact your ISP — packet loss of this magnitude often indicates a line fault.",
                ],
                "affected_component": "Network / Physical Layer",
            })

        # ── Rule 6: Moderate packet loss (10-50%) ─────────────────────────────
        elif pkt_loss > 10:
            issues.append({
                "id": "moderate_packet_loss",
                "title": "Moderate Packet Loss",
                "severity": "medium",
                "evidence": (
                    f"{pkt_loss:.0f}% packet loss to {ping_to_check.get('target', 'target')}."
                ),
                "possible_cause": (
                    "Some packets are being dropped during transmission. "
                    "This can be caused by: wireless interference, network congestion, "
                    "or marginal hardware quality."
                ),
                "recommended_solution": [
                    "1. If using Wi-Fi: reduce interference by moving closer to the router or away from microwaves/cordless phones.",
                    "2. Try using a wired Ethernet connection instead of Wi-Fi.",
                    "3. Restart your router.",
                    "4. Run the test during off-peak hours to see if congestion is the issue.",
                ],
                "affected_component": "Network Quality",
            })

        # ── Rule 7 & 8: High latency ──────────────────────────────────────────
        avg_lat = ping_to_check.get("avg_latency_ms")
        if avg_lat is not None:
            if avg_lat > 500:
                issues.append({
                    "id": "very_high_latency",
                    "title": "Very High Network Latency",
                    "severity": "high",
                    "evidence": f"Average round-trip time is {avg_lat:.0f}ms (normal is under 100ms).",
                    "possible_cause": (
                        "Network response times are extremely slow. "
                        "Causes: severe network congestion, distant server location, "
                        "poor ISP routing, Wi-Fi interference, or hardware issues."
                    ),
                    "recommended_solution": [
                        "1. Run a speed test at fast.com or speedtest.net to check your connection quality.",
                        "2. Try connecting via Ethernet cable instead of Wi-Fi.",
                        "3. Check if many devices are using the network simultaneously (streaming, downloading).",
                        "4. Contact your ISP if the problem persists.",
                        "5. Consider the distance to the target server — international servers will have higher latency.",
                    ],
                    "affected_component": "Latency / Network Quality",
                })
            elif avg_lat > 200:
                issues.append({
                    "id": "high_latency",
                    "title": "High Network Latency",
                    "severity": "medium",
                    "evidence": f"Average round-trip time is {avg_lat:.0f}ms (acceptable is under 100ms for most uses).",
                    "possible_cause": (
                        "Network response times are higher than ideal. "
                        "This may affect video calls, gaming, and streaming quality."
                    ),
                    "recommended_solution": [
                        "1. Try using a wired Ethernet connection for lower latency.",
                        "2. Close background applications that consume bandwidth.",
                        "3. Restart your router.",
                        "4. Check the physical distance to the server — it affects latency.",
                    ],
                    "affected_component": "Latency",
                })

        # ── Rule 9 & 10: Port connectivity issues ─────────────────────────────
        if port and not port.get("success"):
            port_error = port.get("error", "")
            if "refused" in port_error.lower():
                issues.append({
                    "id": "port_refused",
                    "title": f"Port {port.get('port')} Closed — Service Not Running",
                    "severity": "medium",
                    "evidence": (
                        f"TCP connection to {port.get('host')}:{port.get('port')} "
                        f"({port.get('service_name', 'Unknown service')}) was refused."
                    ),
                    "possible_cause": (
                        "The host is reachable, but no application is listening on this port. "
                        f"The {port.get('service_name', 'service')} service may not be running, "
                        "or it may be listening on a different port."
                    ),
                    "recommended_solution": [
                        f"1. Verify that the {port.get('service_name', 'service')} service is installed and running on the target machine.",
                        "2. Check if the service is configured to listen on a different port.",
                        "3. If testing a remote server, confirm the server is online.",
                        "4. Check the service logs for startup errors.",
                    ],
                    "affected_component": "Port / Service",
                })
            elif "timed out" in port_error.lower() or "timeout" in port_error.lower():
                issues.append({
                    "id": "port_filtered",
                    "title": f"Port {port.get('port')} Filtered — Possible Firewall Block",
                    "severity": "medium",
                    "evidence": (
                        f"Connection to {port.get('host')}:{port.get('port')} "
                        f"({port.get('service_name', 'Unknown service')}) timed out."
                    ),
                    "possible_cause": (
                        "The connection attempt was not refused (which would be immediate), "
                        "but it timed out waiting for a response. "
                        "This usually means a firewall is silently dropping packets to this port."
                    ),
                    "recommended_solution": [
                        "1. Check the firewall rules on the target machine — ensure the port is allowed inbound.",
                        "2. Check your local firewall (Windows Defender Firewall) — ensure outbound connections are allowed.",
                        "3. If the target is a server you manage, add a firewall exception for this port.",
                        "4. Check if the router's port forwarding is configured correctly.",
                    ],
                    "affected_component": "Firewall / Port",
                })
            else:
                issues.append({
                    "id": "port_error",
                    "title": f"Cannot Connect to Port {port.get('port')}",
                    "severity": "medium",
                    "evidence": f"Port check failed: {port_error}",
                    "possible_cause": "The host may be unreachable, or the port may be blocked.",
                    "recommended_solution": [
                        "1. Verify the hostname and port number are correct.",
                        "2. Check your internet connection.",
                        "3. Try the connection from a different network.",
                    ],
                    "affected_component": "Port Connectivity",
                })

        # ── Rule 11: Routing issue (traceroute didn't reach destination) ──────
        if traceroute and not traceroute.get("reached_destination") and traceroute.get("success") and traceroute.get("hops"):
            issues.append({
                "id": "routing_issue",
                "title": "Possible Routing Issue — Destination Not Reached",
                "severity": "medium",
                "evidence": (
                    f"Traceroute to {traceroute.get('target')} completed {traceroute.get('total_hops')} hops "
                    "but did not reach the destination."
                ),
                "possible_cause": (
                    "Network packets are travelling toward the destination but are being dropped "
                    "at some point along the route. This can be caused by: "
                    "a misconfigured router along the path, the destination blocking traceroute packets, "
                    "or an ISP routing problem."
                ),
                "recommended_solution": [
                    "1. Identify at which hop the packets stop — that is likely where the problem is.",
                    "2. Try a different destination to see if the issue is destination-specific.",
                    "3. Note that some routers and firewalls intentionally block traceroute (ICMP TTL exceeded messages).",
                    "4. Contact your ISP if packets stop at an ISP-managed router.",
                ],
                "affected_component": "Routing",
            })

        # ── Rule 12: Everything looks healthy ─────────────────────────────────
        # Only add this if we actually ran some tests and found no issues
        has_results = any([ping, dns, traceroute, port, ping_gw, ping_inet])
        if not issues and has_results:
            issues.append({
                "id": "healthy",
                "title": "Network Appears Healthy",
                "severity": "info",
                "evidence": "All diagnostic tests completed successfully without detecting significant issues.",
                "possible_cause": "No problems found with the diagnostics that were run.",
                "recommended_solution": [
                    "No action required.",
                    "If you are still experiencing issues, they may be application-specific rather than network-related.",
                    "Consider running more specific tests if a particular service is not working.",
                ],
                "affected_component": "General",
            })
        elif not has_results:
            issues.append({
                "id": "no_data",
                "title": "No Diagnostic Data Available",
                "severity": "info",
                "evidence": "No diagnostic tests have been run yet.",
                "possible_cause": "Diagnostics have not been executed.",
                "recommended_solution": [
                    "Run the Network Information scan first.",
                    "Then run Ping, DNS, and Traceroute tests.",
                    "Return to the AI Assistant to analyse the results.",
                ],
                "affected_component": "General",
            })

        # ── Calculate health score ────────────────────────────────────────────
        score = 100
        for issue in issues:
            score -= self._SEVERITY_DEDUCTIONS.get(issue["severity"], 0)
        score = max(0, min(100, score))

        if score >= 80:
            overall_health = "Good"
        elif score >= 60:
            overall_health = "Fair"
        elif score >= 30:
            overall_health = "Poor"
        else:
            overall_health = "Critical"

        # ── Build summary ─────────────────────────────────────────────────────
        critical_issues = [i for i in issues if i["severity"] == "critical"]
        high_issues = [i for i in issues if i["severity"] == "high"]
        medium_issues = [i for i in issues if i["severity"] == "medium"]

        if not has_results:
            summary = "No diagnostic tests have been run yet. Use the diagnostic tools to gather data, then click 'Analyse' to see results."
        elif issues and issues[0]["id"] == "healthy":
            summary = (
                "All diagnostic tests completed successfully. "
                "Your network connection appears to be working normally. "
                f"Network health score: {score}/100."
            )
        else:
            parts = []
            if critical_issues:
                parts.append(f"{len(critical_issues)} critical issue(s) found")
            if high_issues:
                parts.append(f"{len(high_issues)} high-priority issue(s)")
            if medium_issues:
                parts.append(f"{len(medium_issues)} medium-priority issue(s)")

            summary = (
                f"Network analysis complete. {', '.join(parts)}. "
                f"Overall health score: {score}/100 ({overall_health}). "
                "Review the issues below for detailed explanations and step-by-step solutions."
            )

        # ── Top recommendations ───────────────────────────────────────────────
        recommendations = []
        for issue in issues:
            if issue["severity"] in ("critical", "high") and issue["recommended_solution"]:
                recommendations.append(issue["recommended_solution"][0])

        if not recommendations and issues and issues[0]["id"] != "healthy":
            recommendations = ["Review each identified issue and follow the recommended solutions."]

        return {
            "issues": issues,
            "overall_health": overall_health,
            "health_score": score,
            "summary": summary,
            "recommendations": recommendations,
            "timestamp": datetime.now().isoformat(),
        }


if __name__ == "__main__":
    import json
    engine = TroubleshootingEngine()

    # Test with simulated failed DNS
    test_data = {
        "dns_result": {
            "success": False,
            "domain": "example.com",
            "error": "getaddrinfo failed: nodename nor servname provided",
        },
        "ping_result": {
            "success": False,
            "target": "8.8.8.8",
            "avg_latency_ms": None,
            "packet_loss_pct": 100.0,
            "error": "Request timed out",
        },
    }

    result = engine.analyse(test_data)
    print(json.dumps(result, indent=2))
